; [Update: 25/10/2026 01:30]
; Inno Setup Script: Biên dịch bộ cài đặt DuMa Phone 1.0 Clean Edition
; Tạo file DuMa_Phone_Setup_v1.0.exe cài đặt độc lập trên Windows

[Setup]
AppId={{DUMA-PHONE-CLEAN-V100-20261025}}
AppName=DuMa Phone Info Changer
AppVersion=1.0.0
AppVerName=DuMa Phone v1.0 Clean Edition
AppPublisher=DuMa Phone Team
AppPublisherURL=https://tcm.io.vn
DefaultDirName={autopf}\DuMa Phone
DefaultGroupName=DuMa Phone
OutputDir=.
OutputBaseFilename=DuMa_Phone_Setup_v1.0
SetupIconFile=app.ico
Compression=lzma2/ultra64
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
UninstallDisplayIcon={app}\DuMa_1.0.exe

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "DuMa_1.0.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "DuMa_1.0.exe.config"; DestDir: "{app}"; Flags: ignoreversion
Source: "app.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "HDSD_DUMA.txt"; DestDir: "{app}"; Flags: ignoreversion isreadme
Source: "Lib\*"; DestDir: "{app}\Lib"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "Source\*"; DestDir: "{app}\Source"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "scrcpy\*"; DestDir: "{app}\scrcpy"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\DuMa Phone"; Filename: "{app}\DuMa_1.0.exe"; IconFilename: "{app}\app.ico"
Name: "{group}\{cm:UninstallProgram,DuMa Phone}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\DuMa Phone"; Filename: "{app}\DuMa_1.0.exe"; IconFilename: "{app}\app.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\DuMa_1.0.exe"; Description: "{cm:LaunchProgram,DuMa Phone}"; Flags: nowait postinstall skipifsilent
