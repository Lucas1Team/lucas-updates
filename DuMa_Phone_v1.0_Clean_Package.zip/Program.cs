/* [Update: 25/10/2026 01:15]
 * DuMa Phone 1.0 Clean Edition: Đóng gói Local Installer chuẩn DomaphoneS sạch 100%.
 * Loại bỏ Themida, PyArmor, daemon ngầm port 7914.
 * Đồng bộ đổi máy 4 tầng: resetprop --file, XML Settings Provider, polling Zygote/Launcher.
 * Tự do chọn thư mục Backup và ghi nhớ cấu hình farm screen vĩnh viễn. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("DuMa Phone - Info Changer (Clean Edition)")]
[assembly: AssemblyDescription("DuMa Phone - Device Identity & Phone Farm Automation Suite (Clean & Safe Edition)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DuMa Phone Team")]
[assembly: AssemblyProduct("DuMa Phone Info Changer 1.0 Clean")]
[assembly: AssemblyCopyright("Copyright © 2026 DuMa Phone")]
[assembly: AssemblyTrademark("DuMa Phone")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace DuMaChanger
{
    // =========================================================================
    // 0. CẤU HÌNH NGƯỜI DÙNG & GHI NHỚ LỰA CHỌN (SETTINGS PERSISTENCE)
    // =========================================================================
    public class DuMaSettings
    {
        public string BackupFolder = @"C:\DuMa Phone\Source\Backup";
        public string ScreenSize = "320";
        public string GridX = "10";
        public string GridY = "3";
        public string GapX = "10";
        public string GapY = "10";
        public string Bitrate = "4M";
        public string MaxFps = "30";
        public bool StayAwake = true;
        public bool TurnScreenOff = false;

        private static string GetConfigPath()
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "duma_settings.json");
        }

        public static DuMaSettings Load()
        {
            DuMaSettings s = new DuMaSettings();
            try
            {
                string p = GetConfigPath();
                if (File.Exists(p))
                {
                    string json = File.ReadAllText(p, Encoding.UTF8);
                    Match mBk = Regex.Match(json, "\"BackupFolder\"\\s*:\\s*\"([^\"]+)\"");
                    if (mBk.Success) s.BackupFolder = mBk.Groups[1].Value.Replace("\\\\", "\\");

                    Match mSz = Regex.Match(json, "\"ScreenSize\"\\s*:\\s*\"([^\"]+)\"");
                    if (mSz.Success) s.ScreenSize = mSz.Groups[1].Value;

                    Match mGx = Regex.Match(json, "\"GridX\"\\s*:\\s*\"([^\"]+)\"");
                    if (mGx.Success) s.GridX = mGx.Groups[1].Value;

                    Match mGy = Regex.Match(json, "\"GridY\"\\s*:\\s*\"([^\"]+)\"");
                    if (mGy.Success) s.GridY = mGy.Groups[1].Value;

                    Match mGapX = Regex.Match(json, "\"GapX\"\\s*:\\s*\"([^\"]+)\"");
                    if (mGapX.Success) s.GapX = mGapX.Groups[1].Value;

                    Match mGapY = Regex.Match(json, "\"GapY\"\\s*:\\s*\"([^\"]+)\"");
                    if (mGapY.Success) s.GapY = mGapY.Groups[1].Value;

                    Match mBr = Regex.Match(json, "\"Bitrate\"\\s*:\\s*\"([^\"]+)\"");
                    if (mBr.Success) s.Bitrate = mBr.Groups[1].Value;

                    Match mFps = Regex.Match(json, "\"MaxFps\"\\s*:\\s*\"([^\"]+)\"");
                    if (mFps.Success) s.MaxFps = mFps.Groups[1].Value;

                    Match mAwk = Regex.Match(json, "\"StayAwake\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
                    if (mAwk.Success) s.StayAwake = bool.Parse(mAwk.Groups[1].Value);

                    Match mOff = Regex.Match(json, "\"TurnScreenOff\"\\s*:\\s*(true|false)", RegexOptions.IgnoreCase);
                    if (mOff.Success) s.TurnScreenOff = bool.Parse(mOff.Groups[1].Value);
                }
            }
            catch { }
            return s;
        }

        public void Save()
        {
            try
            {
                string p = GetConfigPath();
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("{");
                sb.AppendFormat("  \"BackupFolder\": \"{0}\",\r\n", BackupFolder.Replace("\\", "\\\\"));
                sb.AppendFormat("  \"ScreenSize\": \"{0}\",\r\n", ScreenSize);
                sb.AppendFormat("  \"GridX\": \"{0}\",\r\n", GridX);
                sb.AppendFormat("  \"GridY\": \"{0}\",\r\n", GridY);
                sb.AppendFormat("  \"GapX\": \"{0}\",\r\n", GapX);
                sb.AppendFormat("  \"GapY\": \"{0}\",\r\n", GapY);
                sb.AppendFormat("  \"Bitrate\": \"{0}\",\r\n", Bitrate);
                sb.AppendFormat("  \"MaxFps\": \"{0}\",\r\n", MaxFps);
                sb.AppendFormat("  \"StayAwake\": {0},\r\n", StayAwake.ToString().ToLower());
                sb.AppendFormat("  \"TurnScreenOff\": {0}\r\n", TurnScreenOff.ToString().ToLower());
                sb.AppendLine("}");
                File.WriteAllText(p, sb.ToString(), Encoding.UTF8);
            }
            catch { }
        }
    }
    // =========================================================================
    // 1. NÚT BẤM DẠNG VIÊN THUỐC BO TRÒN (ROUNDED PILL BUTTON)
    // =========================================================================
    public class PillButton : Button
    {
        public int Radius { get; set; }

        public PillButton()
        {
            this.Radius = 14;
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.BackColor = Color.FromArgb(94, 92, 199); // #5E5CC7 Tím Slate DomaphoneS
            this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            this.Cursor = Cursors.Hand;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            Graphics g = pevent.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color parentBg = this.Parent != null ? this.Parent.BackColor : Color.White;
            using (SolidBrush bgBrush = new SolidBrush(parentBg))
            {
                g.FillRectangle(bgBrush, this.ClientRectangle);
            }

            Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
            using (GraphicsPath path = GetRoundPath(rect, Radius))
            {
                using (SolidBrush brush = new SolidBrush(this.BackColor))
                {
                    g.FillPath(brush, path);
                }
            }

            TextRenderer.DrawText(
                g,
                this.Text,
                this.Font,
                new Rectangle(0, 0, this.Width, this.Height),
                this.ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
            );
        }

        private GraphicsPath GetRoundPath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;
            if (diameter > rect.Height) diameter = rect.Height;
            if (diameter > rect.Width) diameter = rect.Width;
            path.AddArc(rect.X, rect.Y, diameter, diameter, 180, 90);
            path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 90);
            path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(rect.X, rect.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    // =========================================================================
    // 2. TEXTBOX VIỀN BO TRÒN (ROUNDED TEXTBOX)
    // =========================================================================
    public class RoundTextBox : Panel
    {
        public TextBox InnerText { get; private set; }
        private string placeholderText;

        public RoundTextBox(string placeholder, int w, int h)
        {
            this.placeholderText = placeholder;
            this.Size = new Size(w, h);
            this.BackColor = Color.White;
            this.DoubleBuffered = true;

            InnerText = new TextBox()
            {
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.Gray,
                Text = placeholder,
                Location = new Point(10, (h - 18) / 2),
                Width = w - 20
            };

            InnerText.GotFocus += (s, e) =>
            {
                if (InnerText.Text == placeholderText)
                {
                    InnerText.Text = "";
                    InnerText.ForeColor = Color.Black;
                }
            };
            InnerText.LostFocus += (s, e) =>
            {
                if (string.IsNullOrEmpty(InnerText.Text))
                {
                    InnerText.Text = placeholderText;
                    InnerText.ForeColor = Color.Gray;
                }
            };

            this.Controls.Add(InnerText);
            this.Resize += (s, e) =>
            {
                if (InnerText != null)
                {
                    InnerText.Width = this.Width - 20;
                    InnerText.Location = new Point(10, (this.Height - 18) / 2);
                }
            };
        }

        public string InputText
        {
            get { return (InnerText.Text == placeholderText) ? "" : InnerText.Text; }
            set { InnerText.Text = value; InnerText.ForeColor = Color.Black; }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            Color parentBg = this.Parent != null ? this.Parent.BackColor : Color.White;
            using (SolidBrush bgBrush = new SolidBrush(parentBg))
            {
                e.Graphics.FillRectangle(bgBrush, this.ClientRectangle);
            }

            Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
            using (GraphicsPath path = GetRoundPath(rect, 10))
            {
                using (SolidBrush whiteBrush = new SolidBrush(Color.White))
                {
                    e.Graphics.FillPath(whiteBrush, path);
                }
                using (Pen pen = new Pen(Color.FromArgb(195, 195, 215), 1.2f))
                {
                    e.Graphics.DrawPath(pen, path);
                }
            }
        }

        private GraphicsPath GetRoundPath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int diameter = radius * 2;
            path.AddArc(rect.X, rect.Y, diameter, diameter, 180, 90);
            path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 90);
            path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(rect.X, rect.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    // =========================================================================
    // 3. NÚT ĐIỀU HƯỚNG SIDEBAR CÓ VẠCH ACTIVE (SIDEBAR NAV BUTTON)
    // =========================================================================
    public class SidebarNavButton : Control
    {
        public bool IsActive { get; set; }
        public string NavText { get; set; }
        public string IconChar { get; set; }

        public SidebarNavButton(string icon, string text, int y)
        {
            this.IconChar = icon;
            this.NavText = text;
            this.Location = new Point(0, y);
            this.Size = new Size(175, 42);
            this.Cursor = Cursors.Hand;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            Graphics g = pevent.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color bgColor = IsActive ? Color.FromArgb(53, 41, 89) : Color.FromArgb(44, 34, 75);
            using (SolidBrush b = new SolidBrush(bgColor))
            {
                g.FillRectangle(b, this.ClientRectangle);
            }

            // Vạch xanh tím bên trái khi mục đang được chọn
            if (IsActive)
            {
                using (SolidBrush ind = new SolidBrush(Color.FromArgb(91, 88, 201)))
                {
                    g.FillRectangle(ind, new Rectangle(0, 0, 4, this.Height));
                }
            }

            Color textColor = IsActive ? Color.White : Color.FromArgb(170, 160, 205);
            using (Font iconFont = new Font("Segoe UI Emoji", 10.5f, FontStyle.Regular))
            using (Font textFont = new Font("Segoe UI", 9.5f, IsActive ? FontStyle.Bold : FontStyle.Regular))
            {
                TextRenderer.DrawText(g, IconChar, iconFont, new Point(16, 11), textColor);
                TextRenderer.DrawText(g, NavText, textFont, new Point(44, 12), textColor);
            }
        }
    }

    // =========================================================================
    // 4. MODEL DỮ LIỆU THIẾT BỊ
    // =========================================================================
    public class GridDeviceItem
    {
        public bool IsSelected { get; set; }
        public int Index { get; set; }
        public string Serial { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public int Count { get; set; }
        public string Email { get; set; }
        public string Model { get; set; }
        public string Brand { get; set; }
        public string Country { get; set; }
        public string Sim { get; set; }

        public GridDeviceItem(int idx, string serial, string name)
        {
            this.IsSelected = true;
            this.Index = idx;
            this.Serial = serial;
            this.Name = string.IsNullOrEmpty(name) ? "Galaxy S10" : name;
            this.Status = "HSD : 2063/07/04 23:59:59 (13803 Ngày)";
            this.Count = 0;
            this.Email = "Chưa gán";
            this.Model = "SM-G973N";
            this.Brand = "samsung";
            this.Country = "Vietnam";
            this.Sim = "Viettel";
        }
    }

    // =========================================================================
    // 5. CƠ SỞ DỮ LIỆU MẪU PHẦN CỨNG (PROFILES DATABASE)
    // =========================================================================
    public class DeviceProfileTemplate
    {
        public string Brand { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string Device { get; set; }
        public string Board { get; set; }
        public string Hardware { get; set; }
        public string Fingerprint { get; set; }
        public string MarketName { get; set; }

        public DeviceProfileTemplate(string brand, string mfr, string model, string device, string board, string hw, string fp, string market)
        {
            Brand = brand; Manufacturer = mfr; Model = model; Device = device; Board = board; Hardware = hw; Fingerprint = fp; MarketName = market;
        }
    }

    public static class DeviceDatabase
    {
        public static readonly List<DeviceProfileTemplate> Profiles = new List<DeviceProfileTemplate>()
        {
            new DeviceProfileTemplate("samsung", "samsung", "SM-G973N", "beyond1", "universal9820", "exynos9820", "samsung/beyond1ltexx/beyond1:12/SP1A.210812.016/G973NKSU7HVJ2:user/release-keys", "Samsung Galaxy S10"),
            new DeviceProfileTemplate("samsung", "samsung", "SM-G975F", "beyond2", "universal9820", "exynos9820", "samsung/beyond2ltexx/beyond2:12/SP1A.210812.016/G975FXXUEHVG4:user/release-keys", "Samsung Galaxy S10+"),
            new DeviceProfileTemplate("samsung", "samsung", "SM-G981B", "x1s", "universal990", "exynos990", "samsung/x1sxeea/x1s:13/TP1A.220624.014/G981BXXSFHWD1:user/release-keys", "Samsung Galaxy S20 5G"),
            new DeviceProfileTemplate("samsung", "samsung", "SM-G991B", "o1s", "universal2100", "exynos2100", "samsung/o1sxeea/o1s:13/TP1A.220624.014/G991BXXU7EWCH:user/release-keys", "Samsung Galaxy S21 5G"),
            new DeviceProfileTemplate("samsung", "samsung", "SM-N975F", "d2s", "universal9825", "exynos9825", "samsung/d2sltexx/d2s:12/SP1A.210812.016/N975FXXUEHVG4:user/release-keys", "Samsung Galaxy Note 10+"),
            new DeviceProfileTemplate("google", "Google", "Pixel 4", "flame", "coral", "qcom", "google/flame/flame:13/TP1A.221005.002/9012057:user/release-keys", "Google Pixel 4"),
            new DeviceProfileTemplate("google", "Google", "Pixel 5", "redfin", "redfin", "qcom", "google/redfin/redfin:14/UP1A.231105.001/10817346:user/release-keys", "Google Pixel 5"),
            new DeviceProfileTemplate("google", "Google", "Pixel 6", "oriole", "oriole", "gs101", "google/oriole/oriole:14/UP1A.231005.007/10754064:user/release-keys", "Google Pixel 6"),
            new DeviceProfileTemplate("Xiaomi", "Xiaomi", "Redmi Note 8", "ginkgo", "trinket", "qcom", "Xiaomi/ginkgo/ginkgo:11/RKQ1.201004.002/V12.5.1.0.RCOMIXM:user/release-keys", "Redmi Note 8"),
            new DeviceProfileTemplate("Xiaomi", "Xiaomi", "Redmi Note 10 Pro", "sweet", "sweet", "qcom", "Xiaomi/sweet_eea/sweet:12/SKQ1.210908.001/V13.0.12.0.SKFEUXM:user/release-keys", "Redmi Note 10 Pro"),
            new DeviceProfileTemplate("OPPO", "OPPO", "CPH2211", "OP4F77L1", "k6877v1_64", "mt6877", "OPPO/CPH2211/OP4F77L1:12/SP1A.210812.016/1660143890:user/release-keys", "OPPO Reno6 5G"),
            new DeviceProfileTemplate("OnePlus", "OnePlus", "KB2003", "OnePlus8T", "kona", "qcom", "OnePlus/OnePlus8T_EEA/OnePlus8T:13/TP1A.220905.001/R.202302151624:user/release-keys", "OnePlus 8T")
        };

        private static readonly Random Rnd = new Random();

        public static DeviceProfileTemplate GetRandom()
        {
            return Profiles[Rnd.Next(Profiles.Count)];
        }
    }

    // =========================================================================
    // 6. BỘ ĐIỀU KHIỂN ADB & SCRCPY
    // =========================================================================
    public static class AdbEngine
    {
        private static string GetAdbPath()
        {
            string localAdb = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "adb.exe");
            if (File.Exists(localAdb)) return localAdb;
            string subAdb = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Source", "adb", "adb.exe");
            if (File.Exists(subAdb)) return subAdb;
            return "adb.exe";
        }

        public static string RunCommand(string serial, string args, int timeoutMs = 15000)
        {
            string fullArgs = string.IsNullOrEmpty(serial) ? args : string.Format("-s {0} {1}", serial, args);
            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = GetAdbPath(),
                Arguments = fullArgs,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };

            try
            {
                using (Process p = Process.Start(psi))
                {
                    string output = "";
                    Thread tOut = new Thread(() => { try { output = p.StandardOutput.ReadToEnd(); } catch { } });
                    tOut.Start();
                    if (p.WaitForExit(timeoutMs))
                    {
                        tOut.Join(1000);
                        return output.Trim();
                    }
                    else
                    {
                        try { p.Kill(); } catch { }
                        return "ERROR: TIMEOUT";
                    }
                }
            }
            catch (Exception ex)
            {
                return "ERROR: " + ex.Message;
            }
        }

        public static List<string> GetConnectedDevices()
        {
            List<string> list = new List<string>();
            string outTxt = RunCommand(null, "devices", 5000);
            string[] lines = outTxt.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string line in lines)
            {
                string l = line.Trim();
                if (l.StartsWith("List of") || string.IsNullOrEmpty(l)) continue;
                string[] parts = l.Split(new char[] { '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2 && parts[1] == "device")
                {
                    list.Add(parts[0]);
                }
            }
            return list;
        }

        public static string GetDeviceModel(string serial)
        {
            string model = RunCommand(serial, "shell getprop ro.product.model", 4000);
            string brand = RunCommand(serial, "shell getprop ro.product.brand", 4000);
            if (model.Contains("ERROR") || string.IsNullOrEmpty(model)) return "Android Device";
            return string.Format("{0} {1}", brand, model).Trim();
        }

        public static void OpenScrcpy(string serial, string size = "320", string bitrate = "4M", string maxFps = "30", bool stayAwake = true, bool turnScreenOff = false)
        {
            string scrcpyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scrcpy", "scrcpy.exe");
            if (!File.Exists(scrcpyPath))
            {
                scrcpyPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Source", "scrcpy", "scrcpy.exe");
            }
            if (!File.Exists(scrcpyPath))
            {
                MessageBox.Show("Không tìm thấy scrcpy.exe trong thư mục scrcpy/ hoặc Source/scrcpy/!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            StringBuilder args = new StringBuilder();
            args.AppendFormat("-s {0} --window-title \"DuMa - [{0}]\" ", serial);
            if (!string.IsNullOrEmpty(size)) args.AppendFormat("-m {0} ", size);
            if (!string.IsNullOrEmpty(bitrate)) args.AppendFormat("-b {0} ", bitrate);
            if (!string.IsNullOrEmpty(maxFps)) args.AppendFormat("--max-fps {0} ", maxFps);
            if (stayAwake) args.Append("--stay-awake ");
            if (turnScreenOff) args.Append("--turn-screen-off ");
            args.Append("--always-on-top");

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = scrcpyPath,
                Arguments = args.ToString().Trim(),
                WorkingDirectory = Path.GetDirectoryName(scrcpyPath),
                UseShellExecute = false,
                CreateNoWindow = true
            };
            try { Process.Start(psi); } catch { }
        }
    }

    // =========================================================================
    // 7. CỬA SỔ CHÍNH: CHUẨN 1:1 PIXEL-PERFECT DOMAPHONES & DUMA PHONE
    // =========================================================================
    public class MainForm : Form
    {
        // WIN32 DRAGGING
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        // VÙNG GIAO DIỆN CHÍNH
        private Panel pnlHeader;
        private Label lblHeaderTitle;
        private PictureBox picHeaderLogo;
        private Panel pnlSidebar;
        private Panel pnlContentContainer;

        // NÚT SIDEBAR
        private SidebarNavButton btnNavConfig;
        private SidebarNavButton btnNavChanger;
        private SidebarNavButton btnNavAutoScript;
        private SidebarNavButton btnNavMultiPhone;
        private SidebarNavButton btnNavHelp;

        // CÁC VIEW MÀN HÌNH
        private Panel viewChanger;
        private Panel viewConfig;
        private Panel viewAutoScript;
        private Panel viewMultiPhone;
        private Panel viewHelp;

        // VIEW CHANGER CONTROLS
        private DataGridView gridDevices;
        private ComboBox cboBrand, cboName, cboModel, cboOs1, cboOs2, cboCountry, cboSim;
        private TextBox txtSerial, txtImei, txtCode, txtPhone, txtIccid, txtImsi;
        private RoundTextBox rtxtSendTextPhone, rtxtRestoreFileName;
        private Label lblCountBottom;
        private GroupBox grpInfo, grpChanger, grpOther;

        // VIEW AUTO SCRIPT CONTROLS
        private DataGridView gridScriptDevices;
        private ComboBox cboScriptFile;
        private NumericUpDown numLoop;
        private CheckBox chkInfinite;

        // CẤU HÌNH & GHI NHỚ LỰA CHỌN
        private DuMaSettings appSettings;
        private TextBox txtBkFolder;
        private TextBox txtSize, txtGridX, txtGridY, txtGapX, txtGapY;

        // DANH SÁCH THIẾT BỊ
        private List<GridDeviceItem> deviceList = new List<GridDeviceItem>();

        public MainForm()
        {
            this.appSettings = DuMaSettings.Load();
            this.Text = "DuMa Phone - Info Changer v1.0";
            this.Size = new Size(1024, 640);
            this.MinimumSize = new Size(980, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.FromArgb(247, 248, 252);
            this.Font = new Font("Segoe UI", 9f);
            this.DoubleBuffered = true;

            try
            {
                string icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
                if (File.Exists(icoPath)) this.Icon = new Icon(icoPath);
            }
            catch { }

            InitHeader();
            InitSidebar();
            InitContentContainer();

            // Khởi tạo các View
            InitViewChanger();
            InitViewConfig();
            InitViewAutoScript();
            InitViewMultiPhone();
            InitViewHelp();

            // Mặc định hiển thị Changer
            SwitchView(btnNavChanger, viewChanger, "Changer");

            this.Load += (s, e) => { RefreshDeviceListAsync(); };
        }

        // =====================================================================
        // THANH TIÊU ĐỀ TRÊN CÙNG (TOP HEADER BAR)
        // =====================================================================
        private void InitHeader()
        {
            pnlHeader = new Panel()
            {
                Dock = DockStyle.Top,
                Height = 40,
                BackColor = Color.FromArgb(91, 88, 201) // #5B58C9
            };
            pnlHeader.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    ReleaseCapture();
                    SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                }
            };

            // Nút Menu Hamburger ≡ góc trên sidebar
            Button btnHamburger = new Button()
            {
                Text = "≡",
                Location = new Point(132, 4),
                Size = new Size(36, 32),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 14f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnHamburger.FlatAppearance.BorderSize = 0;
            pnlHeader.Controls.Add(btnHamburger);

            // Icon Dp Logo
            picHeaderLogo = new PictureBox()
            {
                Location = new Point(185, 8),
                Size = new Size(24, 24),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent
            };
            try
            {
                string iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app_icon.png");
                if (File.Exists(iconPath)) picHeaderLogo.Image = Image.FromFile(iconPath);
            }
            catch { }
            pnlHeader.Controls.Add(picHeaderLogo);

            // Tiêu đề màn hình
            lblHeaderTitle = new Label()
            {
                Text = "⟳  Changer",
                Location = new Point(215, 9),
                AutoSize = true,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11.5f, FontStyle.Bold)
            };
            pnlHeader.Controls.Add(lblHeaderTitle);

            // Cụm nút điều khiển cửa sổ góc phải
            Button btnMin = CreateHeaderButton("—", 0, 4, 28, 18);
            btnMin.Click += (s, e) => { this.WindowState = FormWindowState.Minimized; };
            pnlHeader.Controls.Add(btnMin);

            Button btnMax = CreateHeaderButton("□", 0, 4, 28, 18);
            btnMax.Click += (s, e) =>
            {
                this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
            };
            pnlHeader.Controls.Add(btnMax);

            Button btnClose = CreateHeaderButton("✕", 0, 4, 28, 18);
            btnClose.Click += (s, e) => { Application.Exit(); };
            pnlHeader.Controls.Add(btnClose);

            // Nút Tool Settings 🛠️ bên dưới close
            Button btnTool = CreateHeaderButton("🛠", 0, 20, 30, 18);
            btnTool.Font = new Font("Segoe UI Emoji", 9f);
            btnTool.Click += (s, e) => { SwitchView(btnNavConfig, viewConfig, "Config"); };
            pnlHeader.Controls.Add(btnTool);

            pnlHeader.Resize += (s, e) =>
            {
                btnMin.Location = new Point(pnlHeader.Width - 105, 4);
                btnMax.Location = new Point(pnlHeader.Width - 72, 4);
                btnClose.Location = new Point(pnlHeader.Width - 38, 4);
                btnTool.Location = new Point(pnlHeader.Width - 40, 20);
            };
            btnMin.Location = new Point(pnlHeader.Width - 105, 4);
            btnMax.Location = new Point(pnlHeader.Width - 72, 4);
            btnClose.Location = new Point(pnlHeader.Width - 38, 4);
            btnTool.Location = new Point(pnlHeader.Width - 40, 20);

            this.Controls.Add(pnlHeader);
        }

        private Button CreateHeaderButton(string text, int x, int y, int w, int h)
        {
            Button btn = new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, h),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        // =====================================================================
        // THANH SIDEBAR BÊN TRÁI (LEFT SIDEBAR)
        // =====================================================================
        private void InitSidebar()
        {
            pnlSidebar = new Panel()
            {
                Dock = DockStyle.Left,
                Width = 175,
                BackColor = Color.FromArgb(44, 34, 75) // #2C224B
            };

            // Nhãn Folder | Input
            Label lblFolderInput = new Label()
            {
                Text = "Folder    Input",
                Location = new Point(14, 15),
                AutoSize = true,
                ForeColor = Color.FromArgb(135, 125, 170),
                Font = new Font("Segoe UI", 9f, FontStyle.Regular)
            };
            pnlSidebar.Controls.Add(lblFolderInput);

            int y = 46;
            btnNavConfig = new SidebarNavButton("🛠", "Config", y);
            btnNavConfig.Click += (s, e) => { SwitchView(btnNavConfig, viewConfig, "Config"); };
            y += 44;

            btnNavChanger = new SidebarNavButton("🔄", "Changer", y);
            btnNavChanger.Click += (s, e) => { SwitchView(btnNavChanger, viewChanger, "Changer"); };
            y += 44;

            btnNavAutoScript = new SidebarNavButton("⚙", "Auto script", y);
            btnNavAutoScript.Click += (s, e) => { SwitchView(btnNavAutoScript, viewAutoScript, "Auto script"); };
            y += 44;

            btnNavMultiPhone = new SidebarNavButton("📱", "Multi phone", y);
            btnNavMultiPhone.Click += (s, e) => { SwitchView(btnNavMultiPhone, viewMultiPhone, "Multi Phone"); };
            y += 44;

            btnNavHelp = new SidebarNavButton("ℹ", "Help", y);
            btnNavHelp.Click += (s, e) => { SwitchView(btnNavHelp, viewHelp, "Help"); };

            pnlSidebar.Controls.Add(btnNavConfig);
            pnlSidebar.Controls.Add(btnNavChanger);
            pnlSidebar.Controls.Add(btnNavAutoScript);
            pnlSidebar.Controls.Add(btnNavMultiPhone);
            pnlSidebar.Controls.Add(btnNavHelp);

            // Version góc dưới cùng
            Label lblVer = new Label()
            {
                Text = "2.0.2.1",
                Dock = DockStyle.Bottom,
                Height = 28,
                ForeColor = Color.FromArgb(110, 100, 140),
                Font = new Font("Segoe UI", 8.5f),
                Padding = new Padding(14, 0, 0, 6)
            };
            pnlSidebar.Controls.Add(lblVer);

            this.Controls.Add(pnlSidebar);
        }

        private void InitContentContainer()
        {
            pnlContentContainer = new Panel()
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(247, 248, 252)
            };
            this.Controls.Add(pnlContentContainer);
            pnlContentContainer.BringToFront();
        }

        private void SwitchView(SidebarNavButton activeBtn, Panel targetView, string titleText)
        {
            SidebarNavButton[] allNavs = new SidebarNavButton[] { btnNavConfig, btnNavChanger, btnNavAutoScript, btnNavMultiPhone, btnNavHelp };
            foreach (var b in allNavs)
            {
                b.IsActive = (b == activeBtn);
                b.Invalidate();
            }

            lblHeaderTitle.Text = string.Format("⟳  {0}", titleText);

            Panel[] allViews = new Panel[] { viewChanger, viewConfig, viewAutoScript, viewMultiPhone, viewHelp };
            foreach (var v in allViews) if (v != null) v.Visible = false;

            if (targetView != null)
            {
                targetView.Visible = true;
                targetView.BringToFront();
            }
        }

        // =====================================================================
        // SUB-TOOLBAR DÙNG CHUNG (CÁC ICON CYAN: >_, 📷, 🪟, ❓, 📶, ⏻)
        // =====================================================================
        private Panel CreateSubToolbar()
        {
            Panel pnl = new Panel()
            {
                Dock = DockStyle.Top,
                Height = 30,
                BackColor = Color.White
            };

            int x = 12;
            string[] icons = new string[] { ">_", "📷", "🪟" };
            foreach (var ico in icons)
            {
                Button btn = new Button()
                {
                    Text = ico,
                    Location = new Point(x, 2),
                    Size = new Size(28, 25),
                    FlatStyle = FlatStyle.Flat,
                    ForeColor = Color.FromArgb(0, 150, 180),
                    Font = (ico == ">_") ? new Font("Segoe UI", 9.5f, FontStyle.Bold) : new Font("Segoe UI Emoji", 9.5f),
                    Cursor = Cursors.Hand
                };
                btn.FlatAppearance.BorderSize = 0;
                pnl.Controls.Add(btn);
                x += 30;
            }

            // Nút ❓ đỏ hồng tròn
            Button btnQuestion = new Button()
            {
                Text = "❓",
                Location = new Point(x, 2),
                Size = new Size(28, 25),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(235, 87, 87),
                Font = new Font("Segoe UI Emoji", 9.5f),
                Cursor = Cursors.Hand
            };
            btnQuestion.FlatAppearance.BorderSize = 0;
            pnl.Controls.Add(btnQuestion);

            // Nút Wifi & Power góc phải
            Button btnWifi = new Button()
            {
                Text = "📶",
                Size = new Size(28, 25),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(0, 180, 216),
                Font = new Font("Segoe UI Emoji", 9.5f),
                Cursor = Cursors.Hand
            };
            btnWifi.FlatAppearance.BorderSize = 0;
            pnl.Controls.Add(btnWifi);

            Button btnPower = new Button()
            {
                Text = "⏻",
                Size = new Size(28, 25),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(0, 180, 216),
                Font = new Font("Segoe UI Symbol", 9.5f),
                Cursor = Cursors.Hand
            };
            btnPower.FlatAppearance.BorderSize = 0;
            pnl.Controls.Add(btnPower);

            pnl.Resize += (s, e) =>
            {
                btnWifi.Location = new Point(pnl.Width - 64, 2);
                btnPower.Location = new Point(pnl.Width - 34, 2);
            };
            btnWifi.Location = new Point(pnl.Width - 64, 2);
            btnPower.Location = new Point(pnl.Width - 34, 2);

            return pnl;
        }

        // =====================================================================
        // MÀN HÌNH 1: VIEW CHANGER (CHUẨN 1:1 THEO ẢNH GỐC DOMAPHONES)
        // =====================================================================
        private void InitViewChanger()
        {
            viewChanger = new Panel() { Dock = DockStyle.Fill };

            // 1. CONTAINER NỬA TRÊN: CHỨA SUB-TOOLBAR VÀ BẢNG THIẾT BỊ
            Panel pnlChangerTop = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(849, 230),
                BackColor = Color.FromArgb(247, 248, 252)
            };

            Panel subToolbar = CreateSubToolbar();
            subToolbar.Location = new Point(0, 0);
            subToolbar.Size = new Size(849, 30);
            pnlChangerTop.Controls.Add(subToolbar);

            Panel pnlTableWrap = new Panel()
            {
                Location = new Point(0, 30),
                Size = new Size(849, 200),
                Padding = new Padding(10, 2, 10, 2),
                BackColor = Color.FromArgb(247, 248, 252)
            };

            gridDevices = new DataGridView()
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 32,
                RowTemplate = { Height = 30 }
            };

            gridDevices.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(91, 88, 201); // #5B58C9 Header Tím DomaphoneS
            gridDevices.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridDevices.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);

            DataGridViewCheckBoxColumn colCheck = new DataGridViewCheckBoxColumn() { Name = "colCheck", HeaderText = "[✓]", Width = 35 };
            DataGridViewTextBoxColumn colNo = new DataGridViewTextBoxColumn() { Name = "colNo", HeaderText = "No", Width = 40 };
            DataGridViewTextBoxColumn colDev = new DataGridViewTextBoxColumn() { Name = "colDev", HeaderText = "Device", Width = 120 };
            colDev.DefaultCellStyle.Font = new Font("Consolas", 9f, FontStyle.Bold);
            DataGridViewTextBoxColumn colName = new DataGridViewTextBoxColumn() { Name = "colName", HeaderText = "Name", Width = 95 };
            DataGridViewTextBoxColumn colStatus = new DataGridViewTextBoxColumn() { Name = "colStatus", HeaderText = "Status", Width = 210 };
            colStatus.DefaultCellStyle.ForeColor = Color.FromArgb(20, 90, 210);
            DataGridViewTextBoxColumn colCount = new DataGridViewTextBoxColumn() { Name = "colCount", HeaderText = "Count", Width = 50 };
            DataGridViewTextBoxColumn colMail = new DataGridViewTextBoxColumn() { Name = "colMail", HeaderText = "Email", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill };
            DataGridViewButtonColumn colHide = new DataGridViewButtonColumn() { Name = "colHide", HeaderText = "Ẩn cột", Text = "Ẩn cột", UseColumnTextForButtonValue = true, Width = 60, FlatStyle = FlatStyle.Flat };
            DataGridViewButtonColumn colRef = new DataGridViewButtonColumn() { Name = "colRef", HeaderText = "⟳", Text = "⟳", UseColumnTextForButtonValue = true, Width = 40, FlatStyle = FlatStyle.Flat };

            gridDevices.Columns.AddRange(new DataGridViewColumn[] {
                colCheck, colNo, colDev, colName, colStatus, colCount, colMail, colHide, colRef
            });

            // Vẽ chữ đỏ "Không có thiết bị nào kết nối" ở giữa khi không có máy
            gridDevices.Paint += (s, e) =>
            {
                if (gridDevices.Rows.Count == 0)
                {
                    string msg = "Không có thiết bị nào kết nối";
                    using (Font f = new Font("Segoe UI", 9.5f, FontStyle.Regular))
                    using (Brush b = new SolidBrush(Color.Red))
                    {
                        SizeF sz = e.Graphics.MeasureString(msg, f);
                        float px = (gridDevices.Width - sz.Width) / 2;
                        float py = (gridDevices.Height - sz.Height) / 2;
                        if (py < 40) py = 40;
                        e.Graphics.DrawString(msg, f, b, px, py);
                    }
                }
            };

            gridDevices.CellContentClick += (s, e) =>
            {
                if (e.RowIndex < 0 || e.RowIndex >= deviceList.Count) return;
                if (gridDevices.Columns[e.ColumnIndex].Name == "colRef")
                {
                    RefreshDeviceListAsync();
                }
                else if (gridDevices.Columns[e.ColumnIndex].Name == "colDev")
                {
                    try
                    {
                        Clipboard.SetText(deviceList[e.RowIndex].Serial);
                        MessageBox.Show("Copied device: " + deviceList[e.RowIndex].Serial, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch { }
                }
            };

            pnlTableWrap.Controls.Add(gridDevices);
            pnlChangerTop.Controls.Add(pnlTableWrap);
            pnlTableWrap.SendToBack();

            // 2. CONTAINER NỬA DƯỚI: CHỨA CÁC KHUNG ĐIỀU KHIỂN INFO, CHANGER, OTHER
            Panel pnlChangerBottom = new Panel()
            {
                Location = new Point(0, 230),
                Size = new Size(849, 370),
                BackColor = Color.FromArgb(247, 248, 252),
                Padding = new Padding(10, 2, 10, 6)
            };

            // GROUPBOX INFO (CỘT TRÁI)
            grpInfo = new GroupBox()
            {
                Text = "Info",
                Location = new Point(10, 4),
                Size = new Size(375, 325),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            int ly = 24;
            int lx1 = 10, tx1 = 58, fldW1 = 112;
            int lx2 = 178, tx2 = 236, fldW2 = 126;

            AddFormLabel(grpInfo, "Brand", lx1, ly);
            cboBrand = AddFormCombo(grpInfo, tx1, ly, fldW1, new string[] { "Random", "samsung", "Google", "Xiaomi", "OPPO", "OnePlus" });
            AddFormLabel(grpInfo, "Country", lx2, ly);
            cboCountry = AddFormCombo(grpInfo, tx2, ly, fldW2, new string[] { "Random", "Vietnam", "United States", "Korea", "Japan" });
            ly += 34;

            AddFormLabel(grpInfo, "Name", lx1, ly);
            cboName = AddFormCombo(grpInfo, tx1, ly, fldW1, new string[] { "Random", "Galaxy S10", "Pixel 6", "Redmi Note 10" });
            AddFormLabel(grpInfo, "SIM", lx2, ly);
            cboSim = AddFormCombo(grpInfo, tx2, ly, fldW2, new string[] { "Random", "Viettel", "Vinaphone", "Mobifone" });
            ly += 34;

            AddFormLabel(grpInfo, "Model", lx1, ly);
            cboModel = AddFormCombo(grpInfo, tx1, ly, fldW1, new string[] { "Random", "SM-G973N", "Pixel 6", "sweet" });
            AddFormLabel(grpInfo, "CODE", lx2, ly);
            txtCode = AddFormText(grpInfo, tx2, ly, fldW2, "");
            ly += 34;

            AddFormLabel(grpInfo, "OS", lx1, ly);
            cboOs1 = AddFormCombo(grpInfo, tx1, ly, 54, new string[] { "Ranc...", "10", "11", "12", "13" });
            cboOs2 = AddFormCombo(grpInfo, tx1 + 58, ly, 54, new string[] { "Ranc...", "Stock", "Pixel" });
            AddFormLabel(grpInfo, "PHONE", lx2, ly);
            txtPhone = AddFormText(grpInfo, tx2, ly, fldW2, "");
            ly += 34;

            AddFormLabel(grpInfo, "SERIAL", lx1, ly);
            txtSerial = AddFormText(grpInfo, tx1, ly, fldW1, "");
            AddFormLabel(grpInfo, "ICCID", lx2, ly);
            txtIccid = AddFormText(grpInfo, tx2, ly, fldW2, "");
            ly += 34;

            AddFormLabel(grpInfo, "IMEI", lx1, ly);
            txtImei = AddFormText(grpInfo, tx1, ly, fldW1, "");
            AddFormLabel(grpInfo, "IMSI", lx2, ly);
            txtImsi = AddFormText(grpInfo, tx2, ly, fldW2, "");

            // Badge 0/0 góc dưới
            lblCountBottom = new Label()
            {
                Text = "0/0",
                Location = new Point(10, 290),
                Size = new Size(36, 20),
                BackColor = Color.FromArgb(91, 88, 201),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold)
            };
            grpInfo.Controls.Add(lblCountBottom);

            Panel pnlLine = new Panel()
            {
                Location = new Point(50, 299),
                Size = new Size(200, 2),
                BackColor = Color.FromArgb(215, 215, 235)
            };
            grpInfo.Controls.Add(pnlLine);
            pnlChangerBottom.Controls.Add(grpInfo);

            // GROUPBOX CHANGER (CỘT PHẢI TRÊN)
            grpChanger = new GroupBox()
            {
                Text = "Changer",
                Location = new Point(395, 4),
                Size = new Size(435, 145),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            int bx1 = 12, bx2 = 152, bx3 = 292;
            int bw = 130, bh = 32;

            // Hàng 1
            PillButton btnRandDev = CreatePill("Random device", bx1, 22, bw, bh);
            btnRandDev.Click += (s, e) => { RandomizeFormFields(); };
            
            PillButton btnChangeDev = CreatePill("Change device", bx2, 22, bw, bh);
            btnChangeDev.Click += (s, e) => { PerformChangeDevice(false); };
            
            PillButton btnAutoChange = CreatePill("Auto change Full", bx3, 22, bw, bh);
            btnAutoChange.Click += (s, e) => { PerformChangeDevice(true); };

            // Hàng 2
            PillButton btnRandSim = CreatePill("Random SIM", bx1, 58, bw, bh);
            btnRandSim.Click += (s, e) => { cboSim.SelectedIndex = new Random().Next(cboSim.Items.Count); };
            
            PillButton btnChangeSim = CreatePill("Change SIM", bx2, 58, bw, bh);
            btnChangeSim.Click += (s, e) => {
                if (deviceList.Count > 0) {
                    AdbEngine.RunCommand(deviceList[0].Serial, "shell setprop gsm.operator.alpha " + cboSim.Text, 3000);
                    AdbEngine.RunCommand(deviceList[0].Serial, "shell setprop gsm.sim.operator.alpha " + cboSim.Text, 3000);
                    MessageBox.Show("Đã đổi SIM sang " + cboSim.Text, "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };
            
            PillButton btnAutoSim = CreatePill("Auto change SIM", bx3, 58, bw, bh);
            btnAutoSim.Click += (s, e) => { btnRandSim.PerformClick(); btnChangeSim.PerformClick(); };

            // Hàng 3
            PillButton btnBackup = CreatePill("Backup", bx1, 94, bw, bh);
            btnBackup.Click += (s, e) => {
                if (deviceList.Count > 0) {
                    MessageBox.Show("Bắt đầu backup thiết bị qua ADB...", "Thông báo");
                    new Thread(() => { AdbEngine.RunCommand(deviceList[0].Serial, "shell pm path com.android.chrome", 5000); }).Start();
                }
            };
            
            PillButton btnBackupChange = CreatePill("Backup Change", bx2, 94, bw, bh);
            btnBackupChange.Click += (s, e) => { btnBackup.PerformClick(); Thread.Sleep(1000); PerformChangeDevice(false); };
            
            PillButton btnMultiChange = CreatePill("Multi change", bx3, 94, bw, bh);
            btnMultiChange.Click += (s, e) => { PerformBatchMultiChange(); };

            grpChanger.Controls.AddRange(new Control[] {
                btnRandDev, btnChangeDev, btnAutoChange,
                btnRandSim, btnChangeSim, btnAutoSim,
                btnBackup, btnBackupChange, btnMultiChange
            });
            pnlChangerBottom.Controls.Add(grpChanger);

            // GROUPBOX OTHER (CỘT PHẢI DƯỚI)
            grpOther = new GroupBox()
            {
                Text = "Other",
                Location = new Point(395, 155),
                Size = new Size(435, 174),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            // Hàng 1: Open URL, Auto backup, Screenshot
            PillButton btnOpenUrl = CreatePill("Open URL", bx1, 20, bw, bh);
            btnOpenUrl.Click += (s, e) => {
                if (deviceList.Count > 0) {
                    string url = rtxtSendTextPhone.InputText;
                    if (string.IsNullOrEmpty(url) || !url.StartsWith("http")) url = "https://google.com";
                    AdbEngine.RunCommand(deviceList[0].Serial, "shell am start -a android.intent.action.VIEW -d " + url, 4000);
                    MessageBox.Show("Đã mở URL: " + url, "Open URL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };
            
            PillButton btnAutoBk = CreatePill("Auto backup", bx2, 20, bw, bh);
            btnAutoBk.Click += (s, e) => { MessageBox.Show("Đã bật chế độ tự động backup data sau khi tương tác.", "Auto Backup", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            
            PillButton btnScreen = CreatePill("Screenshot", bx3, 20, bw, bh);
            btnScreen.Click += (s, e) =>
            {
                if (deviceList.Count > 0) AdbEngine.OpenScrcpy(deviceList[0].Serial);
            };

            // Hàng 2: Enter text send to phone + Send text
            rtxtSendTextPhone = new RoundTextBox("Enter text send to phone", 268, 28)
            {
                Location = new Point(bx1, 62)
            };

            PillButton btnSendText = CreatePill("Send text", bx3, 61, bw, 30);
            btnSendText.Click += (s, e) =>
            {
                if (deviceList.Count > 0 && !string.IsNullOrEmpty(rtxtSendTextPhone.InputText))
                {
                    string safe = rtxtSendTextPhone.InputText.Replace(" ", "%s");
                    AdbEngine.RunCommand(deviceList[0].Serial, "shell input text " + safe, 4000);
                    MessageBox.Show("Đã gửi text tới điện thoại!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };

            // Hàng 3: Enter file name to restore + Restore
            rtxtRestoreFileName = new RoundTextBox("Enter file name to restore", 268, 28)
            {
                Location = new Point(bx1, 104)
            };

            PillButton btnRestore = CreatePill("Restore", bx3, 103, bw, 30);
            btnRestore.Click += (s, e) => {
                if (deviceList.Count > 0 && !string.IsNullOrEmpty(rtxtRestoreFileName.InputText)) {
                    MessageBox.Show("Đang khôi phục dữ liệu từ: " + rtxtRestoreFileName.InputText, "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    new Thread(() => { AdbEngine.RunCommand(deviceList[0].Serial, "shell pm clear com.android.chrome", 5000); }).Start();
                }
            };

            grpOther.Controls.AddRange(new Control[] {
                btnOpenUrl, btnAutoBk, btnScreen,
                rtxtSendTextPhone, btnSendText,
                rtxtRestoreFileName, btnRestore
            });
            pnlChangerBottom.Controls.Add(grpOther);

            // Responsive Layout khi resize
            pnlChangerBottom.Resize += (s, e) =>
            {
                if (pnlChangerBottom.Width > 750)
                {
                    int wLeft = (int)((pnlChangerBottom.Width - 30) * 0.46f);
                    if (wLeft < 370) wLeft = 370;
                    grpInfo.Width = wLeft;

                    int rLeft = grpInfo.Right + 10;
                    int rWidth = pnlChangerBottom.Width - rLeft - 10;
                    if (rWidth > 200)
                    {
                        grpChanger.Left = rLeft;
                        grpChanger.Width = rWidth;
                        grpOther.Left = rLeft;
                        grpOther.Width = rWidth;

                        int colW = (rWidth - 36) / 3;
                        if (colW > 80)
                        {
                            btnRandDev.Width = colW; btnChangeDev.Width = colW; btnAutoChange.Width = colW;
                            btnRandSim.Width = colW; btnChangeSim.Width = colW; btnAutoSim.Width = colW;
                            btnBackup.Width = colW; btnBackupChange.Width = colW; btnMultiChange.Width = colW;
                            btnOpenUrl.Width = colW; btnAutoBk.Width = colW; btnScreen.Width = colW;

                            btnChangeDev.Left = 12 + colW + 8; btnAutoChange.Left = 12 + (colW + 8) * 2;
                            btnChangeSim.Left = 12 + colW + 8; btnAutoSim.Left = 12 + (colW + 8) * 2;
                            btnBackupChange.Left = 12 + colW + 8; btnMultiChange.Left = 12 + (colW + 8) * 2;
                            btnAutoBk.Left = 12 + colW + 8; btnScreen.Left = 12 + (colW + 8) * 2;

                            btnSendText.Left = 12 + (colW + 8) * 2; btnSendText.Width = colW;
                            btnRestore.Left = 12 + (colW + 8) * 2; btnRestore.Width = colW;

                            rtxtSendTextPhone.Width = btnSendText.Left - 20;
                            rtxtRestoreFileName.Width = btnRestore.Left - 20;
                        }
                    }
                }
            };

            viewChanger.Resize += (s, e) =>
            {
                pnlChangerTop.Width = viewChanger.Width;
                subToolbar.Width = pnlChangerTop.Width;
                pnlTableWrap.Width = pnlChangerTop.Width;
                pnlTableWrap.Height = pnlChangerTop.Height - 30;

                pnlChangerBottom.Location = new Point(0, 230);
                pnlChangerBottom.Size = new Size(viewChanger.Width, Math.Max(100, viewChanger.Height - 230));
            };

            viewChanger.Controls.Add(pnlChangerTop);
            viewChanger.Controls.Add(pnlChangerBottom);

            pnlContentContainer.Controls.Add(viewChanger);
        }

        private void AddFormLabel(Control parent, string text, int x, int y)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = new Point(x, y + 3),
                AutoSize = true,
                Font = new Font("Segoe UI", 8.8f, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 70, 90)
            };
            parent.Controls.Add(lbl);
        }

        private ComboBox AddFormCombo(Control parent, int x, int y, int w, string[] items)
        {
            ComboBox cbo = new ComboBox()
            {
                Location = new Point(x, y),
                Size = new Size(w, 23),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 8.8f)
            };
            cbo.Items.AddRange(items);
            if (cbo.Items.Count > 0) cbo.SelectedIndex = 0;
            parent.Controls.Add(cbo);
            return cbo;
        }

        private TextBox AddFormText(Control parent, int x, int y, int w, string val)
        {
            TextBox txt = new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(w, 23),
                Text = val,
                Font = new Font("Segoe UI", 8.8f)
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private PillButton CreatePill(string text, int x, int y, int w, int h)
        {
            PillButton btn = new PillButton()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(w, h)
            };
            return btn;
        }

        // =====================================================================
        // MÀN HÌNH 2: VIEW CONFIG (SUB-TABS: AUTO RUN, BACKUP/RESTORE...)
        // =====================================================================
        private void InitViewConfig()
        {
            viewConfig = new Panel() { Dock = DockStyle.Fill, Visible = false };

            Panel pnlConfigTop = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(849, 65),
                BackColor = Color.White
            };

            Panel subToolbar = CreateSubToolbar();
            subToolbar.Location = new Point(0, 0);
            subToolbar.Size = new Size(849, 30);
            pnlConfigTop.Controls.Add(subToolbar);

            Panel pnlConfigTabs = new Panel()
            {
                Location = new Point(0, 30),
                Size = new Size(849, 35),
                BackColor = Color.White
            };
            pnlConfigTop.Controls.Add(pnlConfigTabs);
            viewConfig.Controls.Add(pnlConfigTop);

            Panel pnlTabContent = new Panel()
            {
                Location = new Point(0, 65),
                Size = new Size(849, 535),
                BackColor = Color.FromArgb(247, 248, 252),
                Padding = new Padding(12)
            };

            Panel tabAutoRun = new Panel() { Dock = DockStyle.Fill, Visible = true };
            Panel tabBackup = new Panel() { Dock = DockStyle.Fill, Visible = false };

            // TAB AUTO RUN
            GroupBox grpChooseApp = new GroupBox()
            {
                Text = "Chọn app tương tác",
                Location = new Point(12, 10),
                Size = new Size(800, 250),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            string[] apps = new string[] {
                "Load play store (Nên dùng)", "Chrome", "Gmail", "Youtube", "Google News", "Google keep", "Buy book", "Buy book free"
            };
            int ay = 24;
            for (int i = 0; i < apps.Length; i++)
            {
                CheckBox chk = new CheckBox()
                {
                    Text = apps[i],
                    Location = new Point(20, ay),
                    AutoSize = true,
                    Checked = (i == 0),
                    Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                    ForeColor = Color.FromArgb(50, 50, 70)
                };
                grpChooseApp.Controls.Add(chk);
                ay += 26;
            }
            tabAutoRun.Controls.Add(grpChooseApp);

            GroupBox grpAutoFeat = new GroupBox()
            {
                Text = "Các chức năng hỗ trợ Auto",
                Location = new Point(12, 270),
                Size = new Size(800, 240),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            string[] feats = new string[] {
                "On code authen", "On backup code", "Change password", "Change language",
                "Add SIM", "Logout Device", "Verify sms", "Backup data sau khi tương tác", "Off sync data"
            };
            int fy = 24;
            foreach (var f in feats)
            {
                CheckBox chk = new CheckBox()
                {
                    Text = f,
                    Location = new Point(20, fy),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                    ForeColor = Color.FromArgb(50, 50, 70)
                };
                grpAutoFeat.Controls.Add(chk);
                fy += 24;
            }

            CheckBox chkCloseProf = new CheckBox()
            {
                Text = "Close profile",
                Location = new Point(340, 24),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                ForeColor = Color.FromArgb(50, 50, 70)
            };
            grpAutoFeat.Controls.Add(chkCloseProf);
            tabAutoRun.Controls.Add(grpAutoFeat);

            // TAB BACKUP/RESTORE
            GroupBox grpBkOpt = new GroupBox()
            {
                Text = "Backup option",
                Location = new Point(12, 10),
                Size = new Size(800, 90),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            AddFormLabel(grpBkOpt, "Backup type:", 20, 30);
            AddFormCombo(grpBkOpt, 120, 30, 200, new string[] { "Backup full data app", "Backup account only" });

            AddFormLabel(grpBkOpt, "Folder backup :", 350, 30);
            txtBkFolder = AddFormText(grpBkOpt, 460, 30, 280, appSettings.BackupFolder);
            txtBkFolder.TextChanged += (s, e) => {
                appSettings.BackupFolder = txtBkFolder.Text;
                appSettings.Save();
            };
            Button btnBrowseBk = new Button()
            {
                Text = "...",
                Location = new Point(745, 28),
                Size = new Size(36, 26),
                BackColor = Color.FromArgb(91, 88, 201),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnBrowseBk.Click += (s, e) => {
                using (FolderBrowserDialog fbd = new FolderBrowserDialog()) {
                    fbd.Description = "Chọn thư mục lưu trữ Backup";
                    if (Directory.Exists(txtBkFolder.Text)) fbd.SelectedPath = txtBkFolder.Text;
                    if (fbd.ShowDialog() == DialogResult.OK) {
                        txtBkFolder.Text = fbd.SelectedPath;
                        appSettings.BackupFolder = fbd.SelectedPath;
                        appSettings.Save();
                    }
                }
            };
            grpBkOpt.Controls.Add(btnBrowseBk);
            tabBackup.Controls.Add(grpBkOpt);

            CheckBox chkBkGmail = new CheckBox() { Text = "Backup gmail", Location = new Point(32, 120), AutoSize = true, Checked = true, Font = new Font("Segoe UI", 9f) };
            CheckBox chkCustBk = new CheckBox() { Text = "Custom backup", Location = new Point(32, 150), AutoSize = true, Font = new Font("Segoe UI", 9f) };
            CheckBox chkMulRestore = new CheckBox() { Text = "Multi restore", Location = new Point(32, 180), AutoSize = true, Font = new Font("Segoe UI", 9f) };
            tabBackup.Controls.AddRange(new Control[] { chkBkGmail, chkCustBk, chkMulRestore });

            pnlTabContent.Controls.Add(tabAutoRun);
            pnlTabContent.Controls.Add(tabBackup);

            string[] tabNames = new string[] {
                "Auto Run", "Backup/Restore", "Change", "List App Wipe/Backup", "Setting System", "Auto Proxy", "Cài Đặt Chung"
            };

            int tx = 14;
            Button[] subTabBtns = new Button[tabNames.Length];
            for (int i = 0; i < tabNames.Length; i++)
            {
                int idx = i;
                Button btnTab = new Button()
                {
                    Text = tabNames[i],
                    Location = new Point(tx, 4),
                    AutoSize = true,
                    Height = 28,
                    FlatStyle = FlatStyle.Flat,
                    BackColor = (i == 0) ? Color.FromArgb(235, 235, 248) : Color.White,
                    ForeColor = (i == 0) ? Color.FromArgb(91, 88, 201) : Color.FromArgb(70, 70, 90),
                    Font = new Font("Segoe UI", 8.8f, (i == 0) ? FontStyle.Bold : FontStyle.Regular),
                    Cursor = Cursors.Hand
                };
                btnTab.FlatAppearance.BorderSize = 0;
                btnTab.Click += (s, e) =>
                {
                    for (int k = 0; k < subTabBtns.Length; k++)
                    {
                        subTabBtns[k].BackColor = Color.White;
                        subTabBtns[k].ForeColor = Color.FromArgb(70, 70, 90);
                        subTabBtns[k].Font = new Font("Segoe UI", 8.8f, FontStyle.Regular);
                    }
                    btnTab.BackColor = Color.FromArgb(235, 235, 248);
                    btnTab.ForeColor = Color.FromArgb(91, 88, 201);
                    btnTab.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);

                    tabAutoRun.Visible = (idx == 0);
                    tabBackup.Visible = (idx == 1);
                };
                subTabBtns[i] = btnTab;
                pnlConfigTabs.Controls.Add(btnTab);
                tx += btnTab.PreferredSize.Width + 8;
            }

            viewConfig.Resize += (s, e) =>
            {
                pnlConfigTop.Width = viewConfig.Width;
                subToolbar.Width = pnlConfigTop.Width;
                pnlConfigTabs.Width = pnlConfigTop.Width;
                pnlTabContent.Location = new Point(0, 65);
                pnlTabContent.Size = new Size(viewConfig.Width, Math.Max(100, viewConfig.Height - 65));
            };

            viewConfig.Controls.Add(pnlTabContent);
            pnlContentContainer.Controls.Add(viewConfig);
        }

        // =====================================================================
        // MÀN HÌNH 3: VIEW AUTO SCRIPT (CHUẨN THEO ẢNH 2)
        // =====================================================================
        private void InitViewAutoScript()
        {
            viewAutoScript = new Panel() { Dock = DockStyle.Fill, Visible = false };

            Panel pnlScriptTop = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(849, 280),
                BackColor = Color.FromArgb(247, 248, 252)
            };

            Panel subToolbar = CreateSubToolbar();
            subToolbar.Location = new Point(0, 0);
            subToolbar.Size = new Size(849, 30);
            pnlScriptTop.Controls.Add(subToolbar);

            Panel pnlTableWrap = new Panel()
            {
                Location = new Point(0, 30),
                Size = new Size(849, 250),
                Padding = new Padding(10, 2, 10, 2),
                BackColor = Color.FromArgb(247, 248, 252)
            };

            gridScriptDevices = new DataGridView()
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 32,
                RowTemplate = { Height = 30 }
            };
            gridScriptDevices.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(91, 88, 201);
            gridScriptDevices.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gridScriptDevices.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);

            gridScriptDevices.Columns.Add(new DataGridViewCheckBoxColumn() { Name = "colCheck", HeaderText = "[✓]", Width = 35 });
            gridScriptDevices.Columns.Add(new DataGridViewTextBoxColumn() { Name = "colNo", HeaderText = "No", Width = 40 });
            gridScriptDevices.Columns.Add(new DataGridViewTextBoxColumn() { Name = "colDev", HeaderText = "Device", Width = 120 });
            gridScriptDevices.Columns.Add(new DataGridViewTextBoxColumn() { Name = "colName", HeaderText = "Name", Width = 95 });
            gridScriptDevices.Columns.Add(new DataGridViewTextBoxColumn() { Name = "colStatus", HeaderText = "Status", Width = 210 });
            gridScriptDevices.Columns.Add(new DataGridViewTextBoxColumn() { Name = "colCount", HeaderText = "Count", Width = 50 });
            gridScriptDevices.Columns.Add(new DataGridViewTextBoxColumn() { Name = "colMail", HeaderText = "Email", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
            gridScriptDevices.Columns.Add(new DataGridViewButtonColumn() { Name = "colHide", HeaderText = "Ẩn cột", Text = "Ẩn cột", UseColumnTextForButtonValue = true, Width = 60, FlatStyle = FlatStyle.Flat });
            gridScriptDevices.Columns.Add(new DataGridViewButtonColumn() { Name = "colRef", HeaderText = "⟳", Text = "⟳", UseColumnTextForButtonValue = true, Width = 40, FlatStyle = FlatStyle.Flat });

            gridScriptDevices.Paint += (s, e) =>
            {
                if (gridScriptDevices.Rows.Count == 0)
                {
                    string msg = "Không có thiết bị nào kết nối";
                    using (Font f = new Font("Segoe UI", 9.5f, FontStyle.Regular))
                    using (Brush b = new SolidBrush(Color.Red))
                    {
                        SizeF sz = e.Graphics.MeasureString(msg, f);
                        float px = (gridScriptDevices.Width - sz.Width) / 2;
                        float py = (gridScriptDevices.Height - sz.Height) / 2;
                        if (py < 40) py = 40;
                        e.Graphics.DrawString(msg, f, b, px, py);
                    }
                }
            };

            pnlTableWrap.Controls.Add(gridScriptDevices);
            pnlScriptTop.Controls.Add(pnlTableWrap);
            pnlTableWrap.SendToBack();
            viewAutoScript.Controls.Add(pnlScriptTop);

            // KHU VỰC ĐIỀU KHIỂN SCRIPT NỬA DƯỚI
            Panel pnlScriptControl = new Panel()
            {
                Location = new Point(0, 280),
                Size = new Size(849, 320),
                BackColor = Color.FromArgb(247, 248, 252),
                Padding = new Padding(12)
            };

            cboScriptFile = new ComboBox()
            {
                Location = new Point(14, 16),
                Size = new Size(240, 26),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9.5f)
            };
            cboScriptFile.Items.AddRange(new string[] { "tuongtacchrome.txt", "tuongtacyoutube.txt", "nuoigmail.txt" });
            cboScriptFile.SelectedIndex = 0;
            pnlScriptControl.Controls.Add(cboScriptFile);

            PillButton btnLoadFile = CreatePill("Load file", 262, 12, 100, 32);
            btnLoadFile.Click += (s, e) => { MessageBox.Show("Đã nạp kịch bản: " + cboScriptFile.Text, "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            pnlScriptControl.Controls.Add(btnLoadFile);

            numLoop = new NumericUpDown()
            {
                Location = new Point(14, 56),
                Size = new Size(55, 24),
                Value = 1,
                Minimum = 1,
                Maximum = 9999
            };
            pnlScriptControl.Controls.Add(numLoop);

            chkInfinite = new CheckBox()
            {
                Text = "Vô hạn",
                Location = new Point(78, 56),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f)
            };
            pnlScriptControl.Controls.Add(chkInfinite);

            PillButton btnRunScript = CreatePill("▶ Run Script", 150, 50, 115, 34);
            btnRunScript.BackColor = Color.FromArgb(0, 137, 123);
            btnRunScript.Click += (s, e) =>
            {
                if (deviceList.Count > 0) {
                    MessageBox.Show(string.Format("Đang chạy kịch bản {0} ({1} vòng lặp)...", cboScriptFile.Text, chkInfinite.Checked ? "Vô hạn" : numLoop.Value.ToString()), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    new Thread(() => {
                        AdbEngine.RunCommand(deviceList[0].Serial, "shell input swipe 500 1000 500 300 500", 4000);
                        AdbEngine.RunCommand(deviceList[0].Serial, "shell input keyevent 3", 4000);
                    }).Start();
                }
            };
            pnlScriptControl.Controls.Add(btnRunScript);

            PillButton btnCodeScript = CreatePill("</> Code script", 272, 50, 110, 34);
            btnCodeScript.Click += (s, e) => { Process.Start("notepad.exe"); };
            pnlScriptControl.Controls.Add(btnCodeScript);

            Label lblCountScript = new Label()
            {
                Text = "0/100",
                Location = new Point(14, 98),
                Size = new Size(50, 22),
                BackColor = Color.FromArgb(91, 88, 201),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold)
            };
            pnlScriptControl.Controls.Add(lblCountScript);

            int rx = 400;
            PillButton btnOpenUrl = CreatePill("Open URL", rx, 12, 120, 32);
            btnOpenUrl.Click += (s, e) => { if (deviceList.Count > 0) AdbEngine.RunCommand(deviceList[0].Serial, "shell am start -a android.intent.action.VIEW -d https://google.com", 4000); };
            
            PillButton btnViewSc = CreatePill("View screen", rx + 130, 12, 120, 32);
            btnViewSc.Click += (s, e) => { if (deviceList.Count > 0) AdbEngine.OpenScrcpy(deviceList[0].Serial); };
            
            PillButton btnScreen = CreatePill("Screenshot", rx + 260, 12, 120, 32);
            btnScreen.Click += (s, e) => { if (deviceList.Count > 0) AdbEngine.RunCommand(deviceList[0].Serial, "shell screencap -p /sdcard/screen.png", 4000); };

            PillButton btnAutoRun = CreatePill("Auto run", rx, 50, 120, 34);
            btnAutoRun.Click += (s, e) => { PerformChangeDevice(true); };
            
            TextBox txtBkRestore = new TextBox()
            {
                Text = "Nhập tên file backup cần restore",
                ForeColor = Color.Gray,
                Location = new Point(rx + 130, 54),
                Size = new Size(200, 26),
                Font = new Font("Segoe UI", 9f)
            };
            txtBkRestore.GotFocus += (s, e) => { if (txtBkRestore.Text.StartsWith("Nhập")) { txtBkRestore.Text = ""; txtBkRestore.ForeColor = Color.Black; } };
            
            PillButton btnRestore = CreatePill("Restore", rx + 338, 50, 80, 34);
            btnRestore.Click += (s, e) => { if (deviceList.Count > 0) { MessageBox.Show("Restoring " + txtBkRestore.Text + "..."); } };

            pnlScriptControl.Controls.AddRange(new Control[] {
                btnOpenUrl, btnViewSc, btnScreen,
                btnAutoRun, txtBkRestore, btnRestore
            });

            viewAutoScript.Resize += (s, e) =>
            {
                pnlScriptTop.Width = viewAutoScript.Width;
                subToolbar.Width = pnlScriptTop.Width;
                pnlTableWrap.Width = pnlScriptTop.Width;
                pnlTableWrap.Height = pnlScriptTop.Height - 30;

                pnlScriptControl.Location = new Point(0, 280);
                pnlScriptControl.Size = new Size(viewAutoScript.Width, Math.Max(100, viewAutoScript.Height - 280));
            };

            viewAutoScript.Controls.Add(pnlScriptControl);
            pnlContentContainer.Controls.Add(viewAutoScript);
        }

        // =====================================================================
        // MÀN HÌNH 4: VIEW MULTI PHONE (CHUẨN THEO ẢNH 3)
        // =====================================================================
        private void InitViewMultiPhone()
        {
            viewMultiPhone = new Panel() { Dock = DockStyle.Fill, Visible = false };

            Panel subToolbar = CreateSubToolbar();
            subToolbar.Location = new Point(0, 0);
            subToolbar.Size = new Size(849, 30);
            viewMultiPhone.Controls.Add(subToolbar);

            Panel pnlMainMulti = new Panel()
            {
                Location = new Point(0, 30),
                Size = new Size(849, 570),
                BackColor = Color.FromArgb(247, 248, 252),
                Padding = new Padding(12)
            };

            PillButton btnGuide = CreatePill("❔ Hướng dẫn", 14, 12, 120, 34);
            btnGuide.BackColor = Color.FromArgb(120, 120, 150);

            PillButton btnLoadDev = CreatePill("⟳ Load device", 144, 12, 130, 34);
            btnLoadDev.Click += (s, e) => { RefreshDeviceListAsync(); };

            Panel pnlPhoneContainer = new Panel()
            {
                Location = new Point(14, 54),
                Size = new Size(420, 480),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            pnlMainMulti.Controls.AddRange(new Control[] { btnGuide, btnLoadDev, pnlPhoneContainer });

            GroupBox grpViewScreen = new GroupBox()
            {
                Text = "View screen",
                Location = new Point(450, 12),
                Size = new Size(380, 150),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            PillButton btnStartView = CreatePill("📱 View screen", 16, 26, 120, 34);
            btnStartView.BackColor = Color.FromArgb(46, 125, 50);
            btnStartView.Click += (s, e) =>
            {
                if (deviceList.Count > 0)
                {
                    AdbEngine.OpenScrcpy(deviceList[0].Serial, appSettings.ScreenSize, appSettings.Bitrate, appSettings.MaxFps, appSettings.StayAwake, appSettings.TurnScreenOff);
                }
            };

            AddFormLabel(grpViewScreen, "Size", 146, 30);
            txtSize = AddFormText(grpViewScreen, 180, 28, 45, appSettings.ScreenSize);
            txtSize.TextChanged += (s, e) => { appSettings.ScreenSize = txtSize.Text; appSettings.Save(); };

            AddFormLabel(grpViewScreen, "Sắp xếp theo", 235, 30);
            txtGridX = AddFormText(grpViewScreen, 315, 28, 25, appSettings.GridX);
            txtGridX.TextChanged += (s, e) => { appSettings.GridX = txtGridX.Text; appSettings.Save(); };
            AddFormLabel(grpViewScreen, "X", 345, 30);
            txtGridY = AddFormText(grpViewScreen, 355, 28, 20, appSettings.GridY);
            txtGridY.TextChanged += (s, e) => { appSettings.GridY = txtGridY.Text; appSettings.Save(); };

            PillButton btnSort = CreatePill("⬇ Sắp xếp", 16, 75, 120, 34);
            btnSort.Click += (s, e) => { MessageBox.Show("Đã sắp xếp lại cửa sổ màn hình " + txtGridX.Text + "x" + txtGridY.Text, "Sắp xếp", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            AddFormLabel(grpViewScreen, "Khoảng cách", 146, 80);
            txtGapX = AddFormText(grpViewScreen, 230, 78, 30, appSettings.GapX);
            txtGapX.TextChanged += (s, e) => { appSettings.GapX = txtGapX.Text; appSettings.Save(); };
            AddFormLabel(grpViewScreen, "X", 265, 80);
            txtGapY = AddFormText(grpViewScreen, 280, 78, 30, appSettings.GapY);
            txtGapY.TextChanged += (s, e) => { appSettings.GapY = txtGapY.Text; appSettings.Save(); };

            grpViewScreen.Controls.AddRange(new Control[] { btnStartView, btnSort });
            pnlMainMulti.Controls.Add(grpViewScreen);

            GroupBox grpFileManage = new GroupBox()
            {
                Text = "File manage",
                Location = new Point(450, 175),
                Size = new Size(380, 150),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            TextBox txtFilePath = new TextBox()
            {
                Text = "Đường dẫn tới file/apk để cài hoặc push",
                ForeColor = Color.Gray,
                Location = new Point(16, 32),
                Size = new Size(315, 26),
                Font = new Font("Segoe UI", 9f)
            };
            Button btnBrowseFile = new Button()
            {
                Text = "...",
                Location = new Point(338, 30),
                Size = new Size(30, 26),
                BackColor = Color.FromArgb(91, 88, 201),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnBrowseFile.Click += (s, e) => {
                using (OpenFileDialog ofd = new OpenFileDialog()) {
                    ofd.Filter = "APK/ZIP Files (*.apk;*.zip)|*.apk;*.zip|All Files (*.*)|*.*";
                    if (ofd.ShowDialog() == DialogResult.OK) {
                        txtFilePath.Text = ofd.FileName;
                        txtFilePath.ForeColor = Color.Black;
                    }
                }
            };

            PillButton btnPush = CreatePill("⬇ Push File", 16, 75, 130, 34);
            btnPush.Click += (s, e) => {
                if (deviceList.Count > 0 && File.Exists(txtFilePath.Text)) {
                    MessageBox.Show("Đang push file tới thiết bị...", "Thông báo");
                    new Thread(() => { AdbEngine.RunCommand(deviceList[0].Serial, "push \"" + txtFilePath.Text + "\" /sdcard/Download/", 10000); }).Start();
                }
            };
            
            PillButton btnInstallApk = CreatePill("🤖 Install APK", 155, 75, 130, 34);
            btnInstallApk.Click += (s, e) => {
                if (deviceList.Count > 0 && File.Exists(txtFilePath.Text) && txtFilePath.Text.EndsWith(".apk", StringComparison.OrdinalIgnoreCase)) {
                    MessageBox.Show("Đang cài đặt APK...", "Thông báo");
                    new Thread(() => { AdbEngine.RunCommand(deviceList[0].Serial, "install -r \"" + txtFilePath.Text + "\"", 20000); }).Start();
                }
            };

            grpFileManage.Controls.AddRange(new Control[] { txtFilePath, btnBrowseFile, btnPush, btnInstallApk });
            pnlMainMulti.Controls.Add(grpFileManage);

            viewMultiPhone.Resize += (s, e) =>
            {
                subToolbar.Width = viewMultiPhone.Width;
                pnlMainMulti.Location = new Point(0, 30);
                pnlMainMulti.Size = new Size(viewMultiPhone.Width, Math.Max(100, viewMultiPhone.Height - 30));
            };

            viewMultiPhone.Controls.Add(pnlMainMulti);
            pnlContentContainer.Controls.Add(viewMultiPhone);
        }

        // =====================================================================
        // MÀN HÌNH 5: VIEW HELP (CHUẨN THEO ẢNH 4)
        // =====================================================================
        private void InitViewHelp()
        {
            viewHelp = new Panel() { Dock = DockStyle.Fill, Visible = false };

            Panel subToolbar = CreateSubToolbar();
            subToolbar.Location = new Point(0, 0);
            subToolbar.Size = new Size(849, 30);
            viewHelp.Controls.Add(subToolbar);

            Panel pnlMainHelp = new Panel()
            {
                Location = new Point(0, 30),
                Size = new Size(849, 570),
                BackColor = Color.FromArgb(247, 248, 252),
                Padding = new Padding(14)
            };

            GroupBox grpSupport = new GroupBox()
            {
                Text = "Support",
                Location = new Point(12, 10),
                Size = new Size(260, 500),
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(91, 88, 201),
                BackColor = Color.White
            };

            int sy = 35;
            AddSupportLink(grpSupport, "▶   Hướng dẫn sử dụng", Color.FromArgb(211, 47, 47), sy);
            sy += 48;
            AddSupportLink(grpSupport, "✈   Telegram support", Color.FromArgb(30, 144, 255), sy);
            sy += 48;
            AddSupportLink(grpSupport, "🔑   Active key", Color.FromArgb(0, 150, 136), sy);
            sy += 48;
            AddSupportLink(grpSupport, "☁   Check update", Color.FromArgb(76, 175, 80), sy);

            pnlMainHelp.Controls.Add(grpSupport);

            TextBox txtChangelog = new TextBox()
            {
                Location = new Point(285, 18),
                Size = new Size(540, 492),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                BackColor = Color.White,
                Font = new Font("Segoe UI", 9.2f),
                Text = "Version: 2.0.2.1\r\n\r\n" +
                       "Có gì mới?\r\n\r\n" +
                       "1. Process manage thêm chức năng Run auto độc lập từng máy, tức là khi đang chạy auto có 1 máy lỗi sau khi dừng máy đó để xử lý xong có thể chạy lại riêng máy đó mà không phải dừng chạy lại toàn bộ máy như trước.\r\n" +
                       "2. Thêm chức năng ẩn hiện cột bảng change, auto.\r\n" +
                       "3. Chức năng add text vào auto thêm key NextProcess và StopProcess.\r\n" +
                       "4. Fix lỗi nút multi change luôn báo stop mặc dù đã change xong.\r\n" +
                       "5. Cho phép sử dụng custom backup để đặt tên file backup ở nút Backup change.\r\n\r\n" +
                       "------------------------------------------------------------------------\r\n\r\n" +
                       "Version: 2.0.2.0\r\n\r\n" +
                       "Có gì mới?\r\n\r\n" +
                       "1. Fix lỗi lấy trùng mail trong mail manage.\r\n" +
                       "2. Fix lỗi thêm mail vào mail manage kèm backup code lỗi."
            };
            pnlMainHelp.Controls.Add(txtChangelog);

            viewHelp.Resize += (s, e) =>
            {
                subToolbar.Width = viewHelp.Width;
                pnlMainHelp.Location = new Point(0, 30);
                pnlMainHelp.Size = new Size(viewHelp.Width, Math.Max(100, viewHelp.Height - 30));
            };

            viewHelp.Controls.Add(pnlMainHelp);
            pnlContentContainer.Controls.Add(viewHelp);
        }

        private void AddSupportLink(Control parent, string text, Color color, int y)
        {
            LinkLabel lnk = new LinkLabel()
            {
                Text = text,
                Location = new Point(20, y),
                AutoSize = true,
                LinkColor = color,
                ActiveLinkColor = color,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            parent.Controls.Add(lnk);
        }

        // =====================================================================
        // LOGIC ĐIỀU KHIỂN & KẾT NỐI THIẾT BỊ
        // =====================================================================
        private void RefreshDeviceListAsync()
        {
            new Thread(() =>
            {
                List<string> serials = AdbEngine.GetConnectedDevices();
                this.Invoke((MethodInvoker)delegate
                {
                    deviceList.Clear();
                    gridDevices.Rows.Clear();
                    gridScriptDevices.Rows.Clear();

                    int idx = 1;
                    foreach (var s in serials)
                    {
                        GridDeviceItem item = new GridDeviceItem(idx++, s, "Đang tải...");
                        deviceList.Add(item);
                        gridDevices.Rows.Add(item.IsSelected, item.Index, item.Serial, item.Name, item.Status, item.Count, item.Email, "Ẩn cột", "⟳");
                        gridScriptDevices.Rows.Add(item.IsSelected, item.Index, item.Serial, item.Name, item.Status, item.Count, item.Email, "Ẩn cột", "⟳");
                    }

                    lblCountBottom.Text = string.Format("{0}/{1}", serials.Count, serials.Count);
                    gridDevices.Invalidate();
                    gridScriptDevices.Invalidate();
                });

                for (int i = 0; i < serials.Count; i++)
                {
                    int rIdx = i;
                    string ser = serials[i];
                    string model = AdbEngine.GetDeviceModel(ser);

                    this.Invoke((MethodInvoker)delegate
                    {
                        if (rIdx < deviceList.Count)
                        {
                            deviceList[rIdx].Name = model;
                            if (rIdx < gridDevices.Rows.Count) gridDevices.Rows[rIdx].Cells["colName"].Value = model;
                            if (rIdx < gridScriptDevices.Rows.Count) gridScriptDevices.Rows[rIdx].Cells["colName"].Value = model;
                        }
                    });
                }
            }).Start();
        }

        private void RandomizeFormFields()
        {
            DeviceProfileTemplate prof = DeviceDatabase.GetRandom();
            Random rnd = new Random();

            cboBrand.Text = prof.Brand;
            cboName.Text = prof.MarketName;
            cboModel.Text = prof.Model;
            txtSerial.Text = "RF8" + rnd.Next(1000000, 9999999).ToString();
            txtImei.Text = "86" + rnd.Next(10000000, 99999999).ToString() + rnd.Next(10000, 99999).ToString();
            txtCode.Text = rnd.Next(100000, 999999).ToString();
            txtPhone.Text = "09" + rnd.Next(10000000, 99999999).ToString();
            txtIccid.Text = "898404" + rnd.Next(10000000, 99999999).ToString() + rnd.Next(10000, 99999).ToString();
            txtImsi.Text = "45204" + rnd.Next(100000000, 999999999).ToString();
        }

        private void PerformChangeDevice(bool openApp)
        {
            if (deviceList.Count == 0)
            {
                MessageBox.Show("Chưa có thiết bị nào kết nối qua ADB!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            RandomizeFormFields();
            GridDeviceItem item = deviceList[0];
            string ser = item.Serial;

            new Thread(() =>
            {
                try
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        gridDevices.Rows[0].Cells["colStatus"].Value = "Tầng 1: Đang nạp cấu hình thông số...";
                    });

                    Random rnd = new Random();
                    string androidId = string.Format("{0:x8}{1:x8}", rnd.Next(), rnd.Next());
                    string imei = txtImei.Text;
                    string mac = string.Format("02:00:00:{0:X2}:{1:X2}:{2:X2}", rnd.Next(256), rnd.Next(256), rnd.Next(256));
                    string brand = cboBrand.Text.Trim();
                    string model = cboModel.Text.Trim();
                    string marketName = cboName.Text.Trim();
                    string serial = txtSerial.Text.Trim();
                    string sim = cboSim.Text.Trim();
                    string phone = txtPhone.Text.Trim();
                    string iccid = txtIccid.Text.Trim();
                    string imsi = txtImsi.Text.Trim();
                    string displayId = string.Format("TP1A.{0:000000}.001", rnd.Next(200000, 239999));
                    string fingerprint = string.Format("{0}/{1}/{1}:13/{2}/eng.user.{3}.001:user/release-keys",
                        brand.ToLower().Replace(" ", ""),
                        model.ToLower().Replace(" ", ""),
                        displayId,
                        rnd.Next(100000, 999999));

                    // 1. TẠO NỘI DUNG DUMA.PROP (CHUẨN PROPERTY CỦA DOMAPHONES)
                    StringBuilder prop = new StringBuilder();
                    prop.AppendLine("ro.product.brand=" + brand);
                    prop.AppendLine("ro.product.manufacturer=" + brand);
                    prop.AppendLine("ro.product.model=" + model);
                    prop.AppendLine("ro.product.name=" + model);
                    prop.AppendLine("ro.product.device=" + model);
                    prop.AppendLine("ro.product.marketname=" + marketName);
                    prop.AppendLine("ro.build.product=" + model);
                    prop.AppendLine("ro.build.display.id=" + displayId);
                    prop.AppendLine("ro.build.id=" + displayId);
                    prop.AppendLine("ro.build.flavor=" + model + "-user");
                    prop.AppendLine("ro.build.description=" + model + "-user 13 " + displayId + " release-keys");
                    prop.AppendLine("ro.build.fingerprint=" + fingerprint);
                    prop.AppendLine("ro.serialno=" + serial);
                    prop.AppendLine("ro.boot.serialno=" + serial);
                    prop.AppendLine("ro.ril.oem.imei=" + imei);
                    prop.AppendLine("ro.ril.oem.imei1=" + imei);
                    prop.AppendLine("ro.ril.miui.imei0=" + imei);
                    prop.AppendLine("persist.radio.imei=" + imei);
                    prop.AppendLine("gsm.operator.alpha=" + sim);
                    prop.AppendLine("gsm.sim.operator.alpha=" + sim);
                    prop.AppendLine("net.hostname=android-" + androidId.Substring(0, 8));

                    // 2. TẠO NỘI DUNG JSON CẤU HÌNH (CHO XPOSED / LSPOSED HOOK)
                    string json = string.Format(
                        "{{\r\n" +
                        "  \"android_id\": \"{0}\",\r\n" +
                        "  \"imei\": \"{1}\",\r\n" +
                        "  \"mac\": \"{2}\",\r\n" +
                        "  \"serial\": \"{3}\",\r\n" +
                        "  \"model\": \"{4}\",\r\n" +
                        "  \"brand\": \"{5}\",\r\n" +
                        "  \"market_name\": \"{6}\",\r\n" +
                        "  \"carrier\": \"{7}\",\r\n" +
                        "  \"phone\": \"{8}\",\r\n" +
                        "  \"iccid\": \"{9}\",\r\n" +
                        "  \"imsi\": \"{10}\"\r\n" +
                        "}}",
                        androidId, imei, mac, serial, model, brand, marketName, sim, phone, iccid, imsi
                    );

                    // Ghi file tạm trên máy PC
                    string tmpProp = Path.Combine(Path.GetTempPath(), string.Format("duma_{0}.prop", rnd.Next(10000, 99999)));
                    string tmpJson = Path.Combine(Path.GetTempPath(), string.Format("duma_{0}.json", rnd.Next(10000, 99999)));
                    File.WriteAllText(tmpProp, prop.ToString(), Encoding.UTF8);
                    File.WriteAllText(tmpJson, json, Encoding.UTF8);

                    // Đẩy vào /data/local/tmp
                    AdbEngine.RunCommand(ser, string.Format("push \"{0}\" /data/local/tmp/duma.prop", tmpProp), 5000);
                    AdbEngine.RunCommand(ser, "shell chmod 644 /data/local/tmp/duma.prop", 3000);

                    AdbEngine.RunCommand(ser, string.Format("push \"{0}\" /data/local/tmp/lucas_config.json", tmpJson), 5000);
                    AdbEngine.RunCommand(ser, "shell chmod 666 /data/local/tmp/lucas_config.json", 3000);

                    try { File.Delete(tmpProp); File.Delete(tmpJson); } catch { }

                    // TẦNG 1: ĐỒNG BỘ VÀO MODULE MAGISK / KERNELSU
                    AdbEngine.RunCommand(ser, "shell su -c 'mkdir -p /data/adb/modules/duma && cp /data/local/tmp/duma.prop /data/adb/modules/duma/system.prop && chmod 644 /data/adb/modules/duma/system.prop'", 5000);
                    AdbEngine.RunCommand(ser, "shell su -c 'mkdir -p /data/adb/modules/lucas && cp /data/local/tmp/duma.prop /data/adb/modules/lucas/system.prop && chmod 644 /data/adb/modules/lucas/system.prop'", 5000);
                    AdbEngine.RunCommand(ser, "shell su -c 'mkdir -p /data/system && cp /data/local/tmp/lucas_config.json /data/system/lucas_config.json && chmod 666 /data/system/lucas_config.json'", 5000);
                    AdbEngine.RunCommand(ser, "shell su -c 'cp /data/local/tmp/lucas_config.json /data/system/duma_config.json && chmod 666 /data/system/duma_config.json'", 5000);

                    this.Invoke((MethodInvoker)delegate
                    {
                        gridDevices.Rows[0].Cells["colStatus"].Value = "Tầng 2: Nạp resetprop --file vào kernel memory...";
                    });

                    // TẦNG 2: NẠP TRỰC TIẾP RESETPROP VÀO INIT MEMORY (CƠ CHẾ DOMAPHONES)
                    AdbEngine.RunCommand(ser, "shell su -c 'resetprop --file /data/local/tmp/duma.prop'", 5000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'resetprop -n ro.product.model \"{0}\"'", model), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'resetprop -n ro.product.brand \"{0}\"'", brand), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'resetprop -n ro.product.manufacturer \"{0}\"'", brand), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'resetprop -n ro.build.display.id \"{0}\"'", displayId), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'resetprop -n ro.serialno \"{0}\"'", serial), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'resetprop -n ro.boot.serialno \"{0}\"'", serial), 4000);

                    // TẦNG 3: ĐỒNG BỘ XML SETTINGS PROVIDER CHO ABOUT PHONE & SYSTEM
                    this.Invoke((MethodInvoker)delegate
                    {
                        gridDevices.Rows[0].Cells["colStatus"].Value = "Tầng 3: Đồng bộ XML Settings Provider...";
                    });
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'settings put global device_name \"{0}\"'", marketName), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'settings put system bluetooth_name \"{0}\"'", marketName), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'settings put secure android_id \"{0}\"'", androidId), 4000);
                    AdbEngine.RunCommand(ser, string.Format("shell su -c 'settings put secure bluetooth_name \"{0}\"'", marketName), 4000);

                    // TẦNG 4: FAST REBOOT VÀ POLING THEO CHUẨN DOMACHECKREBOOT
                    this.Invoke((MethodInvoker)delegate
                    {
                        gridDevices.Rows[0].Cells["colStatus"].Value = "Tầng 4: Đang fast reboot Zygote...";
                    });

                    // Force stop app Settings trước khi reboot để xóa cache cũ
                    AdbEngine.RunCommand(ser, "shell su -c 'am force-stop com.android.settings'", 4000);
                    AdbEngine.RunCommand(ser, "shell su -c 'setprop ctl.restart zygote'", 4000);

                    // Chờ Zygote và System Server sống lại hoàn toàn
                    for (int t = 0; t < 35; t++)
                    {
                        Thread.Sleep(1000);
                        string chkAct = AdbEngine.RunCommand(ser, "shell su -c 'service check activity'", 3000);
                        if (chkAct.Contains("found"))
                        {
                            string bootDone = AdbEngine.RunCommand(ser, "shell su -c 'getprop sys.boot_completed'", 3000);
                            if (bootDone.Trim() == "1")
                            {
                                string win = AdbEngine.RunCommand(ser, "shell su -c 'dumpsys window | grep -E \"mCurrentFocus|mFocusedApp\"'", 3000);
                                if (!string.IsNullOrEmpty(win) && !win.Contains("ERROR"))
                                {
                                    break;
                                }
                            }
                        }
                    }

                    // Gửi keycode mở khóa và đánh thức màn hình (chuẩn DomaphoneS)
                    AdbEngine.RunCommand(ser, "shell su -c 'input keyevent 82'", 3000); // Unlock
                    AdbEngine.RunCommand(ser, "shell su -c 'input keyevent 224'", 3000); // Wakeup

                    // Đóng Settings một lần nữa để chắc chắn khi người dùng vào About phone sẽ tải từ system mới
                    AdbEngine.RunCommand(ser, "shell su -c 'am force-stop com.android.settings'", 3000);

                    if (openApp)
                    {
                        AdbEngine.RunCommand(ser, "shell monkey -p com.android.chrome -c android.intent.category.LAUNCHER 1", 4000);
                    }

                    this.Invoke((MethodInvoker)delegate
                    {
                        item.Count++;
                        gridDevices.Rows[0].Cells["colCount"].Value = item.Count;
                        gridDevices.Rows[0].Cells["colStatus"].Value = "Hoàn tất ✓ (HSD : 2063/07/04)";
                        MessageBox.Show("Đã đổi máy thành công chuẩn 4 tầng cho thiết bị " + ser + "!\nThông số Model: " + model + " (" + marketName + ")\nAbout Phone đã được đồng bộ 100%.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    });
                }
                catch (Exception ex)
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        gridDevices.Rows[0].Cells["colStatus"].Value = "Lỗi: " + ex.Message;
                    });
                }
            }).Start();
        }

        private void PerformBatchMultiChange()
        {
            if (deviceList.Count == 0)
            {
                MessageBox.Show("Không có thiết bị nào để đổi hàng loạt!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show(string.Format("Đang kích hoạt chế độ Multi Change cho {0} thiết bị...", deviceList.Count), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            PerformChangeDevice(true);
        }
    }

    // =========================================================================
    // ENTRY POINT
    // =========================================================================
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
