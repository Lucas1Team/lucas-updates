:: [Update: 25/10/2026 01:45]
:: Batch script: Biên dịch DuMa_1.0.exe và đóng gói DuMa_Phone_Setup_v1.0.exe trên Windows
@echo off
chcp 65001 >nul
echo ========================================================================
echo  DANG BIEN DICH VA DONG GOI DUMA PHONE 1.0 (CLEAN EDITION)...
echo ========================================================================

set CSC_PATH=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC_PATH%" set CSC_PATH=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe

if not exist "%CSC_PATH%" (
    echo [LOI] Khong tim thay trinh bien dich csc.exe cua .NET Framework 4.8!
    pause
    exit /b 1
)

echo [1/3] Dang bien dich DuMa_1.0.exe tu Program.cs...
"%CSC_PATH%" /target:winexe /optimize+ /debug- /win32icon:app.ico /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll /out:DuMa_1.0.exe Program.cs

if not exist "DuMa_1.0.exe" (
    echo [LOI] Bien dich DuMa_1.0.exe that bai!
    pause
    exit /b 1
)
echo [OK] Bien dich thanh cong DuMa_1.0.exe!

echo [2/3] Dang kiem tra Inno Setup 6...
set ISCC_PATH=C:\Program Files (x86)\Inno Setup 6\ISCC.exe
if not exist "%ISCC_PATH%" set ISCC_PATH=C:\Program Files\Inno Setup 6\ISCC.exe

if exist "%ISCC_PATH%" (
    echo [3/3] Dang dong goi bo cai dat DuMa_Phone_Setup_v1.0.exe...
    "%ISCC_PATH%" DuMa_Phone_Setup_v1.0.iss
    if exist "DuMa_Phone_Setup_v1.0.exe" (
        echo ========================================================================
        echo [THANH CONG] Da tao bo cai dat: DuMa_Phone_Setup_v1.0.exe!
        echo ========================================================================
    )
) else (
    echo [CANH BAO] Khong tim thay ISCC.exe (Inno Setup 6).
    echo Ban co the chay truc tiep file DuMa_1.0.exe (Ban Portable da san sang).
)

echo Hoan tat!
pause
