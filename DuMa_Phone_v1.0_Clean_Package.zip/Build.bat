@echo off
chcp 65001 >nul
title Build DuMa 1.0
echo ========================================================
echo   BUILDING DUMA 1.0 (PHONE FARM CONTROLLER)
echo ========================================================
set CSC_PATH=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe

if not exist "%CSC_PATH%" (
    set CSC_PATH=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe
)

if not exist "%CSC_PATH%" (
    echo [ERROR] Khong tim thay trinh bien dich csc.exe!
    pause
    exit /b 1
)

echo Dang bien dich Program.cs sang DuMa_1.0.exe...
"%CSC_PATH%" /target:winexe /optimize+ /win32icon:app.ico /out:DuMa_1.0.exe Program.cs

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo   [THANH CONG] Da build xong DuMa_1.0.exe!
    echo ========================================================
) else (
    echo.
    echo [THAT BAI] Co loi trong qua trinh bien dich!
)
pause
