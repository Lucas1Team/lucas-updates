:: [Update: 25/10/2026 08:05]
:: Batch script khoi dong lai ADB Server khi dien thoai khong nhan dien
@echo off
chcp 65001 >nul
echo ========================================================================
echo  DANG KHOI DONG LAI ADB SERVER CHO DUMA PHONE...
echo ========================================================================

echo [1/3] Dang dong cac tien trinh ADB dang chay ngam tren Windows...
taskkill /f /im adb.exe 2>nul
taskkill /f /im scrcpy.exe 2>nul

echo [2/3] Dang khoi dong lai ADB Daemon...
adb.exe kill-server 2>nul
adb.exe start-server

echo.
echo [3/3] DANH SACH THIET BI DANG KET NOI:
echo ------------------------------------------------------------------------
adb.exe devices -l
echo ------------------------------------------------------------------------
echo.
echo Neu thiet bi bao 'unauthorized': Hay mo man hinh dien thoai va bam 'Cho phep'.
echo Neu da hien chu 'device': Ban mo lai DuMa_Phone.exe la se nhan 100%!
echo ========================================================================
pause
