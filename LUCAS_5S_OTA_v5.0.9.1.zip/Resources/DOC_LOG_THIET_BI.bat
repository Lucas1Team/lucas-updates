@echo off
chcp 65001 >nul
set "SCRIPT_PATH=%~f0"
set "SCRIPT_DIR=%~dp0"

:parse_args
if "%~1"=="" goto :args_done
if /I "%~1"=="--auto" set "LUCAS_LOG_AUTO=1" & shift & goto :parse_args
if /I "%~1"=="-auto" set "LUCAS_LOG_AUTO=1" & shift & goto :parse_args
if /I "%~1"=="--zip" set "LUCAS_LOG_ZIP=1" & shift & goto :parse_args
if /I "%~1"=="-zip" set "LUCAS_LOG_ZIP=1" & shift & goto :parse_args
if /I "%~1"=="--out" set "LUCAS_LOG_OUT=%~2" & shift & shift & goto :parse_args
if /I "%~1"=="--serials" set "LUCAS_LOG_SERIALS=%~2" & shift & shift & goto :parse_args
if /I "%~1"=="--pc-dir" set "LUCAS_PC_LOG_DIR=%~2" & shift & shift & goto :parse_args
shift
goto :parse_args

:args_done
powershell -NoProfile -ExecutionPolicy Bypass -Command "$code = [System.IO.File]::ReadAllText($env:SCRIPT_PATH, [System.Text.Encoding]::UTF8); $marker = '#__PS_' + 'START__'; $idx = $code.IndexOf($marker); if ($idx -lt 0) { Write-Host 'Loi: Khong tim thay ma PowerShell nhung.' -ForegroundColor Red; exit 1 }; $sb = [scriptblock]::Create($code.Substring($idx + $marker.Length)); & $sb $env:SCRIPT_DIR"
set "RC=%errorlevel%"
if not "%RC%"=="0" (
    if /I not "%LUCAS_LOG_AUTO%"=="1" (
        echo.
        echo Chuong trinh ket thuc voi ma loi %RC%.
        pause
    )
)
exit /b %RC%

#__PS_START__
param([string]$RootDir)

$ErrorActionPreference = 'Continue'
$IsAutoMode = ($env:LUCAS_LOG_AUTO -eq '1')
$CustomOutDir = if ($env:LUCAS_LOG_OUT) { $env:LUCAS_LOG_OUT.Trim().Trim('"') } else { '' }
$CreateZipBundle = ($env:LUCAS_LOG_ZIP -eq '1')
$FilterSerialsRaw = if ($env:LUCAS_LOG_SERIALS) { $env:LUCAS_LOG_SERIALS.Trim().Trim('"') } else { '' }
$PcLogDir = if ($env:LUCAS_PC_LOG_DIR) { $env:LUCAS_PC_LOG_DIR.Trim().Trim('"') } else { '' }

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { [Console]::InputEncoding  = [System.Text.Encoding]::UTF8 } catch {}
if (-not $IsAutoMode) {
    try { $Host.UI.RawUI.WindowTitle = '[LUCAS] Doc & Xuat Log Nhieu Thiet Bi Android (Song Song)' } catch {}
}

$RootDir = if ($RootDir) { $RootDir.TrimEnd('\', '/') } else { (Get-Location).Path }

function Find-AdbExecutable {
    param([string]$BaseDir)
    if ($env:LUCAS_ADB_PATH -and (Test-Path -LiteralPath $env:LUCAS_ADB_PATH)) {
        return (Resolve-Path -LiteralPath $env:LUCAS_ADB_PATH).Path
    }
    $parentDir = ''
    try { $parentDir = Split-Path -Path $BaseDir -Parent } catch {}
    $candidates = @(
        (Join-Path $BaseDir 'adb.exe'),
        (Join-Path $BaseDir 'scrcpy\adb.exe'),
        (Join-Path $BaseDir 'Resources\scrcpy\adb.exe'),
        (Join-Path $BaseDir '1. LUCAS 5S\adb.exe'),
        (Join-Path $BaseDir '1. LUCAS 5S\Resources\scrcpy\adb.exe'),
        (Join-Path $BaseDir '1.TCM Labs\TEST-Lucas\adb.exe'),
        (Join-Path $BaseDir '1.TCM Labs\TEST-Lucas\Resources\scrcpy\adb.exe'),
        (Join-Path $BaseDir 'LC All new\adb.exe')
    )
    if ($parentDir) {
        $candidates += @(
            (Join-Path $parentDir 'adb.exe'),
            (Join-Path $parentDir 'Resources\scrcpy\adb.exe')
        )
    }
    foreach ($p in $candidates) {
        if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
    }
    $cmd = Get-Command 'adb.exe' -ErrorAction SilentlyContinue
    if (-not $cmd) { $cmd = Get-Command 'adb' -ErrorAction SilentlyContinue }
    if ($cmd) { return $cmd.Source }
    return $null
}

function Invoke-AdbText {
    param(
        [string]$AdbPath,
        [string[]]$Arguments,
        [int]$TimeoutMs = 15000
    )
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $AdbPath
    $psi.Arguments = ($Arguments | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ }
    }) -join ' '
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    [void]$proc.Start()

    $outTask = $proc.StandardOutput.ReadToEndAsync()
    $errTask = $proc.StandardError.ReadToEndAsync()

    $exited = $proc.WaitForExit($TimeoutMs)
    if (-not $exited) {
        try { $proc.Kill() } catch {}
        return [PSCustomObject]@{
            ExitCode = -1
            TimedOut = $true
            StdOut   = ''
            StdErr   = "TIMEOUT sau ${TimeoutMs}ms"
        }
    }
    try { [void]$outTask.Wait(3000) } catch {}
    try { [void]$errTask.Wait(3000) } catch {}
    $outStr = if ($outTask.IsCompleted) { $outTask.Result } else { '' }
    $errStr = if ($errTask.IsCompleted) { $errTask.Result } else { '' }

    return [PSCustomObject]@{
        ExitCode = $proc.ExitCode
        TimedOut = $false
        StdOut   = $outStr
        StdErr   = $errStr
    }
}

function Get-ConnectedDevices {
    param([string]$AdbPath)
    $res = Invoke-AdbText -AdbPath $AdbPath -Arguments @('devices', '-l') -TimeoutMs 10000
    $list = @()
    if (-not $res.StdOut) { return $list }

    $lines = $res.StdOut -split "`r?`n"
    foreach ($line in $lines) {
        $trim = $line.Trim()
        if (-not $trim -or $trim -like 'List of devices*' -or $trim -like '*daemon*') { continue }
        if ($trim -match '^(\S+)\s+(device|offline|unauthorized|recovery|sideload|no permissions)(.*)$') {
            $serial = $matches[1]
            $state  = $matches[2]
            $extra  = $matches[3].Trim()
            $model  = ''
            $dev    = ''
            $tid    = ''
            if ($extra -match 'model:(\S+)') { $model = $matches[1] }
            if ($extra -match 'device:(\S+)') { $dev = $matches[1] }
            if ($extra -match 'transport_id:(\S+)') { $tid = $matches[1] }
            $list += [PSCustomObject]@{
                Serial      = $serial
                State       = $state
                Model       = $model
                DeviceCode  = $dev
                TransportId = $tid
                RawExtra    = $extra
            }
        }
    }
    return $list
}

function Select-TargetDevices {
    param($OnlineDevices)
    Write-Host ''
    Write-Host 'Nhap STT may muon doc (vd: 1 hoac 1,3 | Enter = chon tat ca): ' -NoNewline -ForegroundColor Yellow
    $raw = Read-Host
    if ([string]::IsNullOrWhiteSpace($raw)) { return $OnlineDevices }

    $picked = @()
    $tokens = $raw -split '[,\s]+' | Where-Object { $_ -ne '' }
    foreach ($t in $tokens) {
        $num = 0
        if ([int]::TryParse($t, [ref]$num)) {
            if ($num -ge 1 -and $num -le $OnlineDevices.Count) {
                $d = $OnlineDevices[$num - 1]
                if ($picked.Serial -notcontains $d.Serial) { $picked += $d }
            }
        }
    }
    return $picked
}

# Worker scriptblock chay song song trong RunspacePool cho tung dien thoai
$DeviceDumpWorker = {
    param(
        [string]$AdbPath,
        [object]$DeviceObj,
        [int]$Index,
        [string]$SessionDir
    )

    $serial = $DeviceObj.Serial

    function Run-AdbStr {
        param([string[]]$AdbArgs, [int]$TimeoutMs = 15000)
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $AdbPath
        $psi.Arguments = ($AdbArgs | ForEach-Object {
            if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ }
        }) -join ' '
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8

        $p = New-Object System.Diagnostics.Process
        $p.StartInfo = $psi
        [void]$p.Start()
        $oT = $p.StandardOutput.ReadToEndAsync()
        $eT = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($TimeoutMs)) {
            try { $p.Kill() } catch {}
            return [PSCustomObject]@{ Ok = $false; TimedOut = $true; Out = ''; Err = "TIMEOUT (${TimeoutMs}ms)" }
        }
        try { [void]$oT.Wait(3000) } catch {}
        try { [void]$eT.Wait(3000) } catch {}
        return [PSCustomObject]@{
            Ok       = ($p.ExitCode -eq 0)
            TimedOut = $false
            Out      = if ($oT.IsCompleted) { $oT.Result } else { '' }
            Err      = if ($eT.IsCompleted) { $eT.Result } else { '' }
        }
    }

    function Run-AdbRootScript {
        param([string]$ScriptBody, [int]$TimeoutMs = 20000)
        $tmpLocal = [System.IO.Path]::GetTempFileName()
        $remoteSh = "/data/local/tmp/lucas_diag_${Index}_$([Environment]::TickCount -band 0x7FFFFFFF).sh"
        try {
            $enc = New-Object System.Text.UTF8Encoding($false)
            $lfBody = ($ScriptBody -replace "`r`n", "`n")
            [System.IO.File]::WriteAllText($tmpLocal, $lfBody, $enc)
            $pushRes = Run-AdbStr -AdbArgs @('-s', $serial, 'push', $tmpLocal, $remoteSh) -TimeoutMs 8000
            if (-not $pushRes.Ok) { return $pushRes }
            return (Run-AdbStr -AdbArgs @('-s', $serial, 'shell', "su -c 'sh $remoteSh; rm -f $remoteSh'") -TimeoutMs $TimeoutMs)
        } finally {
            try { if (Test-Path -LiteralPath $tmpLocal) { Remove-Item -LiteralPath $tmpLocal -Force -ErrorAction SilentlyContinue } } catch {}
        }
    }

    function Run-AdbToFile {
        param([string[]]$AdbArgs, [string]$OutFile, [int]$TimeoutMs = 45000)
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $AdbPath
        $psi.Arguments = ($AdbArgs | ForEach-Object {
            if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ }
        }) -join ' '
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardErrorEncoding  = [System.Text.Encoding]::UTF8

        $p = New-Object System.Diagnostics.Process
        $p.StartInfo = $psi
        [void]$p.Start()

        $eT = $p.StandardError.ReadToEndAsync()
        $fs = [System.IO.File]::Open($OutFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
        $copyTask = $p.StandardOutput.BaseStream.CopyToAsync($fs)

        $exited = $p.WaitForExit($TimeoutMs)
        $timedOut = $false
        if (-not $exited) {
            $timedOut = $true
            try { $p.Kill() } catch {}
        }
        try { [void]$copyTask.Wait(4000) } catch {}
        try { [void]$eT.Wait(2000) } catch {}
        $fs.Flush()
        $fs.Dispose()

        $errStr = if ($eT.IsCompleted) { $eT.Result } else { '' }
        return [PSCustomObject]@{
            Ok       = (-not $timedOut -and $p.ExitCode -eq 0)
            TimedOut = $timedOut
            Err      = $errStr
        }
    }

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)

    # 1. Doc thong tin thiet bi co ban
    $propCmd = 'echo "MODEL=$(getprop ro.product.model)"; echo "BRAND=$(getprop ro.product.brand)"; echo "MANUFACTURER=$(getprop ro.product.manufacturer)"; echo "DEVICE=$(getprop ro.product.device)"; echo "ANDROID=$(getprop ro.build.version.release)"; echo "SDK=$(getprop ro.build.version.sdk)"; echo "PATCH=$(getprop ro.build.version.security_patch)"; echo "ABI=$(getprop ro.product.cpu.abi)"; echo "FINGERPRINT=$(getprop ro.build.fingerprint)"; echo "UPTIME=$(uptime 2>/dev/null)"; echo "LOGD_SIZE=$(getprop persist.logd.size)"; echo "LOGD_SVC=$(getprop init.svc.logd)"'
    $propRes = Run-AdbStr -AdbArgs @('-s', $serial, 'shell', $propCmd) -TimeoutMs 10000
    $props = @{}
    foreach ($ln in ($propRes.Out -split "`r?`n")) {
        if ($ln -match '^([A-Z0-9_]+)=(.*)$') { $props[$matches[1]] = $matches[2].Trim() }
    }
    $modelName = if ($props['MODEL']) { $props['MODEL'] } elseif ($DeviceObj.Model) { $DeviceObj.Model } else { 'Unknown' }
    $androidVer = if ($props['ANDROID']) { "$($props['ANDROID']) (API $($props['SDK']))" } else { 'N/A' }

    $safeModel  = ($modelName -replace '[^a-zA-Z0-9._-]', '_')
    $safeSerial = ($serial    -replace '[^a-zA-Z0-9._-]', '_')
    $devDirName = ('{0:D2}_{1}_{2}' -f $Index, $safeModel, $safeSerial)
    $devDir     = Join-Path $SessionDir $devDirName
    [void](New-Item -ItemType Directory -Path $devDir -Force)

    # 2. Kiem tra Root (timeout ngan 7s tranh treo popup)
    $rootRes = Run-AdbStr -AdbArgs @('-s', $serial, 'shell', 'su -c id 2>&1') -TimeoutMs 7000
    $rootStatus = 'NO_ROOT'
    if ($rootRes.TimedOut) {
        $rootStatus = 'TIMEOUT_POPUP'
    } elseif ($rootRes.Out -match 'uid=0') {
        $rootStatus = 'ROOT_OK'
    } elseif ($rootRes.Out -match 'Permission denied|denied') {
        $rootStatus = 'DENIED'
    }

    # 3. Tham do nhanh suc khoe logd (<4s) truoc khi dump logcat tranh treo 60-120s neu ROM tat/ket logd
    $logcatFullPath  = Join-Path $devDir '02_logcat_full.txt'
    $logcatCrashPath = Join-Path $devDir '03_logcat_crash.txt'
    $dmesgPath       = Join-Path $devDir '04_dmesg_kernel.txt'
    $sysInfoPath     = Join-Path $devDir '05_thong_tin_he_thong_root.txt'
    $dropboxPath     = Join-Path $devDir '06_dropbox_crashes.txt'
    $summaryPath     = Join-Path $devDir '01_TOM_TAT_LOI.txt'

    $lcBufRes = Run-AdbStr -AdbArgs @('-s', $serial, 'logcat', '-b', 'main,system,crash,events,radio', '-g') -TimeoutMs 3500
    if (-not $lcBufRes.TimedOut -and -not $lcBufRes.Out.Trim()) {
        $lcBufRes = Run-AdbStr -AdbArgs @('-s', $serial, 'logcat', '-b', 'main,system,crash', '-g') -TimeoutMs 3000
    }
    if (-not $lcBufRes.TimedOut -and -not $lcBufRes.Out.Trim() -and $rootStatus -eq 'ROOT_OK') {
        $lcBufRes = Run-AdbStr -AdbArgs @('-s', $serial, 'shell', 'su -c "logcat -g 2>/dev/null"') -TimeoutMs 3500
    }
    $logcatBufferInfo = ($lcBufRes.Out.Trim() -replace "`r?`n", ' | ')

    $logdHung = $false
    if ($lcBufRes.TimedOut -or -not $logcatBufferInfo) {
        $probeRes = Run-AdbStr -AdbArgs @('-s', $serial, 'logcat', '-b', 'main,crash', '-d', '-t', '5') -TimeoutMs 3500
        if (-not $probeRes.TimedOut -and -not $probeRes.Out.Trim() -and $rootStatus -eq 'ROOT_OK') {
            $probeRes = Run-AdbStr -AdbArgs @('-s', $serial, 'shell', 'su -c "logcat -b main,crash -d -t 5 2>/dev/null"') -TimeoutMs 3500
        }
        $logdSizeProp = if ($props.ContainsKey('LOGD_SIZE')) { $props['LOGD_SIZE'] } else { '' }
        if ($probeRes.TimedOut -and ($lcBufRes.TimedOut -or $logdSizeProp -eq '-1' -or $logdSizeProp -eq 'OFF' -or $logdSizeProp -eq '0')) {
            $logdHung = $true
        }
    }

    $logcatSourceMode   = 'main,system,crash,events,radio (adb)'
    $logcatUsedFallback = $false
    if ($logdHung) {
        [System.IO.File]::WriteAllText($logcatFullPath, '', $utf8NoBom)
        [System.IO.File]::WriteAllText($logcatCrashPath, '', $utf8NoBom)
        $lcFullRes  = [PSCustomObject]@{ Ok = $false; TimedOut = $false; Err = 'LOGD_HUNG' }
        $lcCrashRes = [PSCustomObject]@{ Ok = $false; TimedOut = $false; Err = 'LOGD_HUNG' }
        $logcatSourceMode = "LOGD TREO/TAT (persist.logd.size=$($props['LOGD_SIZE']))"
        if (-not $logcatBufferInfo) {
            $logcatBufferInfo = "(LOGD TREO/TAT | persist.logd.size=$($props['LOGD_SIZE']) | init.svc.logd=$($props['LOGD_SVC']))"
        }
    } else {
        $lcFullRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'logcat', '-b', 'main,system,crash,events,radio', '-d', '-v', 'threadtime') -OutFile $logcatFullPath -TimeoutMs 25000
        $lcFullSize = if (Test-Path -LiteralPath $logcatFullPath) { (Get-Item -LiteralPath $logcatFullPath).Length } else { 0 }
        if (-not $lcFullRes.TimedOut -and (-not $lcFullRes.Ok -or $lcFullSize -eq 0)) {
            $lcFullRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'logcat', '-b', 'main,system,crash', '-d', '-v', 'threadtime') -OutFile $logcatFullPath -TimeoutMs 20000
            $lcFullSize = if (Test-Path -LiteralPath $logcatFullPath) { (Get-Item -LiteralPath $logcatFullPath).Length } else { 0 }
            $logcatSourceMode   = 'main,system,crash (fallback)'
            $logcatUsedFallback = $true
        }
        if (-not $lcFullRes.TimedOut -and $lcFullSize -eq 0 -and $rootStatus -eq 'ROOT_OK') {
            $lcRootRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'shell', 'su -c "logcat -b main,system,crash,events,radio -d -v threadtime 2>/dev/null || logcat -b main,system,crash -d -v threadtime 2>/dev/null"') -OutFile $logcatFullPath -TimeoutMs 15000
            $lcFullSize = if (Test-Path -LiteralPath $logcatFullPath) { (Get-Item -LiteralPath $logcatFullPath).Length } else { 0 }
            if ($lcFullSize -gt 0) {
                $lcFullRes = $lcRootRes
                $logcatSourceMode   = 'root su -c logcat (rescued)'
                $logcatUsedFallback = $false
            }
        }

        $lcCrashRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'logcat', '-b', 'crash', '-d', '-v', 'threadtime') -OutFile $logcatCrashPath -TimeoutMs 10000
        $lcCrashSize = if (Test-Path -LiteralPath $logcatCrashPath) { (Get-Item -LiteralPath $logcatCrashPath).Length } else { 0 }
        if (-not $lcCrashRes.TimedOut -and $lcCrashSize -eq 0 -and $rootStatus -eq 'ROOT_OK') {
            $lcCrashRootRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'shell', 'su -c "logcat -b crash -d -v threadtime 2>/dev/null"') -OutFile $logcatCrashPath -TimeoutMs 10000
            if ((Test-Path -LiteralPath $logcatCrashPath) -and (Get-Item -LiteralPath $logcatCrashPath).Length -gt 0) {
                $lcCrashRes = $lcCrashRootRes
            }
        }
    }
    if (-not $logcatBufferInfo) { $logcatBufferInfo = '(Khong doc duoc logcat -g)' }
    elseif ($logcatBufferInfo.Length -gt 220) { $logcatBufferInfo = $logcatBufferInfo.Substring(0, 220) + '...' }

    # 4. Xuat Kernel dmesg & Thong tin he thong / Root / LSPosed / GMS / Tombstones / ANR / DropBox
    $sysSb = New-Object System.Text.StringBuilder
    [void]$sysSb.AppendLine('===============================================================================')
    [void]$sysSb.AppendLine("THONG TIN HE THONG & MOI TRUONG ROOT - [$serial]")
    [void]$sysSb.AppendLine("Thoi gian xuat: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
    [void]$sysSb.AppendLine('===============================================================================')
    foreach ($k in @('MODEL','BRAND','MANUFACTURER','DEVICE','ANDROID','SDK','PATCH','ABI','FINGERPRINT','UPTIME')) {
        [void]$sysSb.AppendLine(('{0,-14}: {1}' -f $k, $props[$k]))
    }
    [void]$sysSb.AppendLine(('ROOT_STATUS   : {0} ({1})' -f $rootStatus, ($rootRes.Out.Trim() -replace "`r?`n", ' ')))
    [void]$sysSb.AppendLine(('LOGCAT_BUFFER : {0}' -f $logcatBufferInfo))

    $dfRes = Run-AdbStr -AdbArgs @('-s', $serial, 'shell', 'df -h /data /sdcard 2>/dev/null') -TimeoutMs 8000
    [void]$sysSb.AppendLine('')
    [void]$sysSb.AppendLine('--- DUNG LUONG BO NHO (/data, /sdcard) ---')
    [void]$sysSb.AppendLine($dfRes.Out.Trim())

    $gmsRes = Run-AdbStr -AdbArgs @('-s', $serial, 'shell', 'dumpsys package com.google.android.gms 2>/dev/null | grep -E "versionName=|versionCode=" | head -n 4; echo "android_id=$(settings get secure android_id 2>/dev/null)"; echo "device_name=$(settings get global device_name 2>/dev/null)"') -TimeoutMs 10000
    [void]$sysSb.AppendLine('')
    [void]$sysSb.AppendLine('--- GOOGLE PLAY SERVICES (GMS) & SETTINGS ---')
    [void]$sysSb.AppendLine($gmsRes.Out.Trim())

    $rootInfoRes = $null
    $dropboxCount = 0
    $dropboxTimedOut = $false
    if ($rootStatus -eq 'ROOT_OK') {
        $dmesgCmd = 'su -c "dmesg -T 2>/dev/null || dmesg"'
        $dmesgRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'shell', $dmesgCmd) -OutFile $dmesgPath -TimeoutMs 20000

        $rootDetailCmd = @'
echo "=== ROOT MANAGER ==="
if [ -d /data/adb/ksu ]; then echo "Type: KernelSU"; ls -la /data/adb/ksu/bin 2>/dev/null; elif [ -d /data/adb/magisk ]; then echo "Type: Magisk"; magisk -v 2>/dev/null; elif [ -d /data/adb/ap ]; then echo "Type: APatch"; else echo "Type: Unknown"; fi
echo ""
echo "=== MODULES (/data/adb/modules) ==="
for m in /data/adb/modules/*; do
  [ -d "$m" ] || continue
  dis=""; [ -f "$m/disable" ] && dis=" [DISABLED]"
  rem=""; [ -f "$m/remove" ] && rem=" [REMOVE]"
  echo "$(basename "$m")$dis$rem"
  grep -E "^(name|version|versionCode)=" "$m/module.prop" 2>/dev/null
done
echo ""
echo "=== LSPOSED ==="
ls -d /data/adb/lspd 2>/dev/null && cat /data/adb/lspd/config/modules.list 2>/dev/null
echo "--- LSPosed Log (last 150 lines / 100 error lines) ---"
if [ -f /data/adb/lspd/log/modules.log ]; then tail -n 150 /data/adb/lspd/log/modules.log; fi
if [ -f /data/adb/lspd/log/modules.log.old ]; then echo "--- modules.log.old (tail 60) ---"; tail -n 60 /data/adb/lspd/log/modules.log.old; fi
if [ -f /data/adb/lspd/log/verbose.log ]; then grep -iE "error|exception|fail|crash" /data/adb/lspd/log/verbose.log | tail -n 100; fi
echo ""
echo "=== LUCAS CONFIG ==="
ls -la /data/system/lucas_config.json /data/adb/modules/lucas_spoofer/system.prop 2>/dev/null
cat /data/system/lucas_config.json 2>/dev/null
echo ""
echo "=== PIF & TRICKYSTORE STATUS (SAFE - NO KEYBOX DUMP) ==="
ls -la /data/adb/modules/playintegrityfix/custom.pif.prop /data/adb/pif.prop /data/adb/tricky_store/keybox.xml /data/adb/tricky_store/target.txt 2>/dev/null
for pf in /data/adb/modules/playintegrityfix/custom.pif.prop /data/adb/pif.prop; do
  if [ -f "$pf" ]; then
    echo "--- $pf (sanitized props) ---"
    grep -E "^(MODEL|MANUFACTURER|BRAND|DEVICE|PRODUCT|SECURITY_PATCH|FIRST_API_LEVEL|FINGERPRINT|BUILD_ID|spoofBuild|spoofProps|spoofProvider|spoofSignature)=" "$pf" 2>/dev/null
  fi
done
echo ""
echo "=== TOMBSTONES & ANR (Gan nhat) ==="
ls -lt /data/tombstones 2>/dev/null | head -n 15
ls -lt /data/anr 2>/dev/null | head -n 15
NEWEST_TB=$(ls -t /data/tombstones/tombstone_* 2>/dev/null | head -n 1)
if [ -n "$NEWEST_TB" ] && [ -f "$NEWEST_TB" ]; then
  echo "--- Noi dung dau Tombstone moi nhat: $NEWEST_TB ---"
  head -n 60 "$NEWEST_TB"
fi
NEWEST_ANR=$(ls -t /data/anr/* 2>/dev/null | head -n 1)
if [ -n "$NEWEST_ANR" ] && [ -f "$NEWEST_ANR" ]; then
  echo "--- Noi dung dau ANR moi nhat: $NEWEST_ANR ---"
  head -n 60 "$NEWEST_ANR"
fi
'@
        $rootInfoRes = Run-AdbRootScript -ScriptBody $rootDetailCmd -TimeoutMs 20000
        [void]$sysSb.AppendLine('')
        [void]$sysSb.AppendLine($rootInfoRes.Out.Trim())

        $dropboxCmd = @'
echo "=== /data/system/dropbox (25 file moi nhat) ==="
ls -lt /data/system/dropbox 2>/dev/null | head -n 26
echo ""
DB_CNT=$(ls -1 /data/system/dropbox 2>/dev/null | grep -iE "crash|anr|tombstone|watchdog|wtf" | wc -l | tr -d " ")
echo "DROPBOX_CRASH_COUNT=$DB_CNT"
echo "=== NOI DUNG 8 FILE CRASH/ANR/TOMBSTONE MOI NHAT TRONG DROPBOX ==="
for f in $(ls -t /data/system/dropbox 2>/dev/null | grep -iE "crash|anr|tombstone|watchdog|wtf" | head -n 8); do
  fp="/data/system/dropbox/$f"
  [ -f "$fp" ] || continue
  echo "--- [$f] ---"
  case "$f" in
    *.gz)
      if command -v gzip >/dev/null 2>&1; then
        gzip -dc "$fp" 2>/dev/null | head -n 80
      elif command -v zcat >/dev/null 2>&1; then
        zcat "$fp" 2>/dev/null | head -n 80
      else
        echo "(File nen .gz - thieu gzip/zcat tren may de giai nen)"
      fi
      ;;
    *)
      head -n 80 "$fp" 2>/dev/null
      ;;
  esac
done
'@
        $dropboxRes = Run-AdbRootScript -ScriptBody $dropboxCmd -TimeoutMs 15000
        $dropboxTimedOut = $dropboxRes.TimedOut
        $dbOut = if ($dropboxRes.TimedOut) { "[CANH BAO] Doc /data/system/dropbox bi TIMEOUT (>15s)." } else { $dropboxRes.Out.Trim() }
        if ($dbOut -match 'DROPBOX_CRASH_COUNT=(\d+)') {
            $dropboxCount = [int]$matches[1]
        }
        [System.IO.File]::WriteAllText($dropboxPath, $dbOut, $utf8NoBom)
    } else {
        $dmesgRes = Run-AdbToFile -AdbArgs @('-s', $serial, 'shell', 'dmesg 2>&1') -OutFile $dmesgPath -TimeoutMs 10000
        [void]$sysSb.AppendLine('')
        [void]$sysSb.AppendLine('[LUU Y] Khong co quyen Root (su), bo qua phan doc modules/LSPosed/tombstones/dropbox.')
        [System.IO.File]::WriteAllText($dropboxPath, "[NO_ROOT] Thiet bi khong co quyen Root ($rootStatus) -> bo qua doc /data/system/dropbox.", $utf8NoBom)
    }

    [System.IO.File]::WriteAllText($sysInfoPath, $sysSb.ToString(), $utf8NoBom)

    # 5. Phan tich tu dong loi tu logcat & dmesg + kiem tra do day du log
    $fatalBlocks   = New-Object System.Collections.Generic.List[string]
    $nativeBlocks  = New-Object System.Collections.Generic.List[string]
    $anrLines      = New-Object System.Collections.Generic.List[string]
    $gmsErrors     = New-Object System.Collections.Generic.List[string]
    $rootHookLines = New-Object System.Collections.Generic.List[string]
    $selinuxLines  = New-Object System.Collections.Generic.List[string]
    $oomLines      = New-Object System.Collections.Generic.List[string]
    $topErrorMap   = @{}

    $logLines = @()
    if (Test-Path -LiteralPath $logcatFullPath) {
        $logLines = [System.IO.File]::ReadAllLines($logcatFullPath, [System.Text.Encoding]::UTF8)
    }

    $totalLines = $logLines.Count
    $logcatFirstTs = ''
    $logcatLastTs  = ''
    for ($i = 0; $i -lt $totalLines; $i++) {
        if ($logLines[$i] -match '^(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
            $logcatFirstTs = $matches[1]
            break
        }
    }
    for ($i = $totalLines - 1; $i -ge 0; $i--) {
        if ($logLines[$i] -match '^(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
            $logcatLastTs = $matches[1]
            break
        }
    }
    $logcatRange = if ($logcatFirstTs -and $logcatLastTs) {
        "$logcatFirstTs -> $logcatLastTs"
    } elseif ($totalLines -gt 0) {
        "(Khong co timestamp chuan)"
    } else {
        "(RONG - 0 dong)"
    }

    for ($i = 0; $i -lt $totalLines; $i++) {
        $ln = $logLines[$i]

        # Java / Kotlin Fatal Exception block + am_crash (events buffer)
        if ($ln -match 'FATAL EXCEPTION|AndroidRuntime:\s*FATAL') {
            $start = [Math]::Max(0, $i - 1)
            $end   = [Math]::Min($totalLines - 1, $i + 18)
            $blk   = ($logLines[$start..$end] -join "`r`n")
            $fatalBlocks.Add("[Dong $($i+1)]`r`n$blk")
        } elseif ($ln -match 'am_crash\s*:') {
            $fatalBlocks.Add("[Dong $($i+1) - events]`r`n$ln")
        }

        # Native Crash (DEBUG / Fatal signal / SIGSEGV / SIGABRT)
        if ($ln -match 'Fatal signal \d+|Build fingerprint:|SIGSEGV|SIGABRT|SIGBUS|tombstone') {
            if ($ln -match 'Fatal signal \d+|SIGSEGV|SIGABRT|SIGBUS') {
                $start = [Math]::Max(0, $i - 2)
                $end   = [Math]::Min($totalLines - 1, $i + 20)
                $blk   = ($logLines[$start..$end] -join "`r`n")
                $nativeBlocks.Add("[Dong $($i+1)]`r`n$blk")
            }
        }

        # ANR / Watchdog
        if ($ln -match 'ANR in |ActivityManager:.*ANR|Watchdog.*blocked|am_anr') {
            $anrLines.Add("[Dong $($i+1)] $ln")
        }

        # GMS / Play Integrity / Play Store / DF-DFERH-01
        if ($ln -match '(?i)(PlayIntegrity|DroidGuard|DF-DFERH-01|Finsky.*(error|fail|exception)|Checkin.*(error|fail)|GoogleAuthUtil|GmsClient.*fail|attestation.*fail)') {
            $gmsErrors.Add("[Dong $($i+1)] $ln")
        }

        # LSPosed / Zygisk / KernelSU / Magisk / resetprop / lucas
        if ($ln -match '(?i)(LSPosed|Xposed|Zygisk|KernelSU|Magisk|resetprop|lucas).*(error|fail|exception|crash|denied|unable|warn)') {
            $rootHookLines.Add("[Dong $($i+1)] $ln")
        }

        # SELinux avc: denied
        if ($ln -match 'avc:\s*denied') {
            $selinuxLines.Add("[Dong $($i+1)] $ln")
        }

        # OutOfMemory / LMK
        if ($ln -match 'OutOfMemoryError|lowmemorykiller|Kill process|oom_kill') {
            $oomLines.Add("[Dong $($i+1)] $ln")
        }

        # Thong ke top dong muc E / F
        if ($ln -match '^\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+\s+\d+\s+\d+\s+([EF])\s+([^:]+):\s*(.*)$') {
            $lvl = $matches[1]
            $tag = $matches[2].Trim()
            $msg = $matches[3].Trim()
            $shortMsg = if ($msg.Length -gt 95) { $msg.Substring(0, 95) + '...' } else { $msg }
            $key = "[$lvl] $tag : $shortMsg"
            if ($topErrorMap.ContainsKey($key)) { $topErrorMap[$key]++ } else { $topErrorMap[$key] = 1 }
        }
    }

    # Quet them dmesg tim loi kernel / avc / oom / usb
    $dmesgErrs = New-Object System.Collections.Generic.List[string]
    $dmesgLineCount = 0
    $dmesgRange = '(RONG)'
    if (Test-Path -LiteralPath $dmesgPath) {
        $dLines = [System.IO.File]::ReadAllLines($dmesgPath, [System.Text.Encoding]::UTF8)
        $dmesgLineCount = $dLines.Count
        if ($dmesgLineCount -gt 0) {
            $dmFirst = if ($dLines[0] -match '^\[([^\]]+)\]') { $matches[1].Trim() } else { '' }
            $dmLast  = if ($dLines[$dmesgLineCount - 1] -match '^\[([^\]]+)\]') { $matches[1].Trim() } else { '' }
            if ($dmFirst -and $dmLast) { $dmesgRange = "$dmFirst -> $dmLast" } else { $dmesgRange = "$dmesgLineCount dong" }
        }
        foreach ($dl in $dLines) {
            if ($dl -match '(?i)(avc:\s*denied|oom|panic|oops|segfault|i/o error|ext4-fs error|f2fs-fs error|usb.*disconnect|resetprop|ksu|magisk.*fail)') {
                $dmesgErrs.Add($dl)
            }
        }
    }

    $missingWarnings = New-Object System.Collections.Generic.List[string]
    if ($logdHung) {
        $missingWarnings.Add("Dich vu logd tren may bi TREO/TAT (persist.logd.size=$($props['LOGD_SIZE']), init.svc.logd=$($props['LOGD_SVC'])) -> Cat nhanh tranh treo, da thu bu dmesg/DropBox/Tombstones!")
    } elseif ($totalLines -eq 0) {
        $missingWarnings.Add('Logcat RONG (0 dong) -> buffer RAM trong hoac ROM tat logd!')
    }
    if ($lcFullRes.TimedOut) {
        $missingWarnings.Add('Logcat FULL bi TIMEOUT (>25s) -> co the bi cat ngang!')
    }
    if ($lcCrashRes.TimedOut) {
        $missingWarnings.Add('Logcat CRASH bi TIMEOUT (>10s)')
    }
    if ($dmesgRes.TimedOut) {
        $missingWarnings.Add('Kernel dmesg bi TIMEOUT (>20s)')
    }
    if ($rootStatus -ne 'ROOT_OK') {
        $missingWarnings.Add("Khong co quyen ROOT ($rootStatus) -> BO SOT dmesg kernel, LSPosed, tombstones, ANR, dropbox!")
    } else {
        if ($rootInfoRes -and $rootInfoRes.TimedOut) {
            $missingWarnings.Add('Doc Root/LSPosed/Tombstones bi TIMEOUT (>20s)')
        }
        if ($dropboxTimedOut) {
            $missingWarnings.Add('Doc /data/system/dropbox bi TIMEOUT (>15s)')
        }
    }
    if ($logcatUsedFallback) {
        $missingWarnings.Add('Logcat fallback ve main,system,crash (khong lay duoc buffer events/radio)')
    }

    $truncatedNotes = New-Object System.Collections.Generic.List[string]
    $secSb = New-Object System.Text.StringBuilder

    function Append-Section {
        param([string]$Title, $Items, [int]$Limit = 25)
        [void]$secSb.AppendLine("===============================================================================")
        [void]$secSb.AppendLine("$Title (Tong: $($Items.Count))")
        [void]$secSb.AppendLine("===============================================================================")
        if ($Items.Count -eq 0) {
            [void]$secSb.AppendLine('(Khong phat hien)')
        } else {
            # Lay cac muc moi nhat (cuoi log) de de bat benh
            $startIdx = [Math]::Max(0, $Items.Count - $Limit)
            if ($startIdx -gt 0) {
                $truncatedNotes.Add("$Title : chi hien $Limit/$($Items.Count) muc moi nhat")
                [void]$secSb.AppendLine("... (Da an $startIdx muc cu hon, xem day du trong 02_logcat_full.txt) ...")
            }
            for ($k = $startIdx; $k -lt $Items.Count; $k++) {
                [void]$secSb.AppendLine($Items[$k])
                [void]$secSb.AppendLine('-------------------------------------------------------------------------------')
            }
        }
        [void]$secSb.AppendLine('')
    }

    Append-Section -Title '1. APP CRASH (FATAL EXCEPTION / AndroidRuntime / am_crash)' -Items $fatalBlocks -Limit 15
    Append-Section -Title '2. NATIVE CRASH (SIGSEGV / SIGABRT / Fatal signal)' -Items $nativeBlocks -Limit 15
    Append-Section -Title '3. ANR / TREO UNG DUNG (ANR / Watchdog)' -Items $anrLines -Limit 30
    Append-Section -Title '4. LOI GMS / PLAY INTEGRITY / CHECKIN / PLAY STORE' -Items $gmsErrors -Limit 40
    Append-Section -Title '5. LOI LSPOSED / ZYGISK / KERNELSU / MAGISK / LUCAS' -Items $rootHookLines -Limit 40
    Append-Section -Title '6. LOI PHAN QUYEN SELINUX (avc: denied)' -Items $selinuxLines -Limit 30
    Append-Section -Title '7. THIEU RAM / OOM / KILL PROCESS' -Items $oomLines -Limit 30
    Append-Section -Title '8. CANH BAO KERNEL (dmesg)' -Items $dmesgErrs -Limit 40

    $completenessTag = if ($missingWarnings.Count -eq 0 -and $truncatedNotes.Count -eq 0) {
        'DU_100%'
    } elseif ($missingWarnings.Count -eq 0) {
        'DU_CAT_TOM_TAT'
    } else {
        'SOT_LOG!'
    }

    # Ghi file 01_TOM_TAT_LOI.txt (dat kiem tra do day du len dau de khong bao gio bi cat khi gui bao cao)
    $sumSb = New-Object System.Text.StringBuilder
    [void]$sumSb.AppendLine('===============================================================================')
    [void]$sumSb.AppendLine("BAO CAO TOM TAT LOI THIET BI: $modelName [$serial]")
    [void]$sumSb.AppendLine("Android: $androidVer | Root: $rootStatus | Tong dong logcat: $totalLines")
    [void]$sumSb.AppendLine("Thoi gian xuat: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
    [void]$sumSb.AppendLine('===============================================================================')
    [void]$sumSb.AppendLine('')
    [void]$sumSb.AppendLine('--- [KIEM TRA DO DAY DU LOG - CHONG BO SOT] ---')
    [void]$sumSb.AppendLine("  * Trang thai thu thap   : $completenessTag")
    [void]$sumSb.AppendLine("  * Khung gio Logcat      : $logcatRange ($totalLines dong | Nguon: $logcatSourceMode)")
    [void]$sumSb.AppendLine("  * Buffer Logcat (log -g): $logcatBufferInfo")
    [void]$sumSb.AppendLine("  * Kernel dmesg          : $dmesgLineCount dong ($dmesgRange)")
    [void]$sumSb.AppendLine("  * DropBox Crash/ANR     : $dropboxCount file (xem 06_dropbox_crashes.txt)")
    if ($missingWarnings.Count -gt 0) {
        foreach ($mw in $missingWarnings) {
            [void]$sumSb.AppendLine("  ! [CANH BAO SOT] $mw")
        }
    }
    if ($truncatedNotes.Count -gt 0) {
        [void]$sumSb.AppendLine("  * Cat bot trong tom tat (van du 100% trong 02_logcat_full.txt):")
        foreach ($tn in $truncatedNotes) {
            [void]$sumSb.AppendLine("      - $tn")
        }
    }
    if ($missingWarnings.Count -eq 0 -and $truncatedNotes.Count -eq 0) {
        [void]$sumSb.AppendLine("  * Xac nhan: Da doc du toan bo nguon log, khong timeout, khong cat bot.")
    }
    [void]$sumSb.AppendLine('')
    [void]$sumSb.AppendLine('--- [THONG KE NHANH] ---')
    [void]$sumSb.AppendLine("  * App Crash (FATAL/am_crash)  : $($fatalBlocks.Count)")
    [void]$sumSb.AppendLine("  * Native Crash (SIGSEGV/ABRT) : $($nativeBlocks.Count)")
    [void]$sumSb.AppendLine("  * ANR / Treo ung dung         : $($anrLines.Count)")
    [void]$sumSb.AppendLine("  * Loi GMS / Play Integrity    : $($gmsErrors.Count)")
    [void]$sumSb.AppendLine("  * Loi LSPosed/Zygisk/Root/App : $($rootHookLines.Count)")
    [void]$sumSb.AppendLine("  * Loi SELinux (avc: denied)   : $($selinuxLines.Count)")
    [void]$sumSb.AppendLine("  * Loi Thieu RAM (OOM/Kill)    : $($oomLines.Count)")
    [void]$sumSb.AppendLine("  * Canh bao Kernel (dmesg)     : $($dmesgErrs.Count)")
    [void]$sumSb.AppendLine("  * DropBox Crash/ANR luu lau   : $dropboxCount")
    [void]$sumSb.AppendLine('')
    [void]$sumSb.Append($secSb.ToString())

    [void]$sumSb.AppendLine('===============================================================================')
    [void]$sumSb.AppendLine('9. TOP 20 DONG LOI (E/F) XUAT HIEN NHIEU NHAT TRONG LOGCAT')
    [void]$sumSb.AppendLine('===============================================================================')
    $topList = $topErrorMap.GetEnumerator() | Sort-Object -Property Value -Descending | Select-Object -First 20
    if (-not $topList) {
        [void]$sumSb.AppendLine('(Khong co dong loi E/F nao)')
    } else {
        foreach ($entry in $topList) {
            [void]$sumSb.AppendLine(('{0,5}x | {1}' -f $entry.Value, $entry.Key))
        }
    }

    [System.IO.File]::WriteAllText($summaryPath, $sumSb.ToString(), $utf8NoBom)
    $sw.Stop()

    return [PSCustomObject]@{
        Index           = $Index
        Serial          = $serial
        Model           = $modelName
        Android         = $androidVer
        RootStatus      = $rootStatus
        TotalLogLines   = $totalLines
        LogcatRange     = $logcatRange
        LogcatBuffer    = $logcatBufferInfo
        LogcatSource    = $logcatSourceMode
        DropboxCount    = $dropboxCount
        CompletenessTag = $completenessTag
        MissingWarnings = @($missingWarnings)
        TruncatedNotes  = @($truncatedNotes)
        FatalCount      = $fatalBlocks.Count
        NativeCount     = $nativeBlocks.Count
        AnrCount        = $anrLines.Count
        GmsErrCount     = $gmsErrors.Count
        HookErrCount    = $rootHookLines.Count
        SelinuxCount    = $selinuxLines.Count
        OomCount        = $oomLines.Count
        DmesgErrCount   = $dmesgErrs.Count
        DeviceDir       = $devDir
        SummaryFile     = $summaryPath
        DurationSec     = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
        FatalPreview    = if ($fatalBlocks.Count -gt 0) { $fatalBlocks[$fatalBlocks.Count - 1] } elseif ($nativeBlocks.Count -gt 0) { $nativeBlocks[$nativeBlocks.Count - 1] } else { '' }
    }
}

function Export-PcRuntimeLogs {
    param(
        [string]$PcDir,
        [string]$FallbackRoot,
        [string]$SessionDir
    )
    $srcRoot = if (-not [string]::IsNullOrWhiteSpace($PcDir) -and (Test-Path -LiteralPath $PcDir)) { $PcDir } elseif (-not [string]::IsNullOrWhiteSpace($RootDir)) { $RootDir } else { $FallbackRoot }
    if ([string]::IsNullOrWhiteSpace($srcRoot) -or -not (Test-Path -LiteralPath $srcRoot)) {
        return [PSCustomObject]@{
            Text          = '[CANH BAO] Khong xac dinh duoc thu muc PC Tool de doc log PC.'
            PcAppLogCount = 0
            HasCrashDump  = $false
            WinErrCount   = 0
            Warnings      = @('Khong tim thay thu muc PC Tool')
        }
    }

    $pcDest = Join-Path $SessionDir 'PC_Logs'
    [void](New-Item -ItemType Directory -Path $pcDest -Force)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $pcWarnings = New-Object System.Collections.Generic.List[string]
    $sumSb = New-Object System.Text.StringBuilder
    [void]$sumSb.AppendLine('=== THONG TIN & LOG TOOL LUCAS TREN PC ===')
    [void]$sumSb.AppendLine("Thu muc PC Tool: $srcRoot")
    [void]$sumSb.AppendLine("OS: $([System.Environment]::OSVersion.VersionString) | 64Bit: $([System.Environment]::Is64BitOperatingSystem)")

    # 1. Inventory EXE + 11 DLL (+ Resources\runtime, Resources\config, config)
    $invSb = New-Object System.Text.StringBuilder
    [void]$invSb.AppendLine("Scan Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | Root: $srcRoot")
    $scanDirs = @($srcRoot, (Join-Path $srcRoot 'config'), (Join-Path $srcRoot 'Resources\runtime'), (Join-Path $srcRoot 'Resources\config'), (Join-Path $srcRoot 'Resources\scrcpy'))
    $bins = @()
    foreach ($sd in $scanDirs) {
        if (Test-Path -LiteralPath $sd) {
            $bins += @(Get-ChildItem -LiteralPath $sd -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '^\.(exe|dll)$' })
        }
    }
    $bins = @($bins | Sort-Object FullName -Unique)
    foreach ($b in $bins) {
        $relName = $b.FullName.Substring($srcRoot.TrimEnd('\').Length).TrimStart('\')
        [void]$invSb.AppendLine(('{0,-48} | {1,10} bytes | {2}' -f $relName, $b.Length, $b.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')))
    }
    [System.IO.File]::WriteAllText((Join-Path $pcDest 'pc_binaries_inventory.txt'), $invSb.ToString(), $utf8NoBom)
    [void]$sumSb.AppendLine("So luong EXE/DLL: $($bins.Count)")

    # 2. crash_dump.log + lucas_pc_*.log (bo qua bitmono-*.log de khong bi de mat log phien PC)
    $crashDump = Join-Path $srcRoot 'crash_dump.log'
    $hasCrashDump = (Test-Path -LiteralPath $crashDump)
    if ($hasCrashDump) {
        Copy-Item -LiteralPath $crashDump -Destination (Join-Path $pcDest 'crash_dump.log') -Force -ErrorAction SilentlyContinue
        [void]$sumSb.AppendLine("Da thu thap crash_dump.log ($((Get-Item $crashDump).Length) bytes)")
    } else {
        [void]$sumSb.AppendLine("crash_dump.log: Khong co (chua ghi nhan crash dot ngot).")
    }

    $logsFolder = Join-Path $srcRoot 'Logs'
    $pcAppLogCount = 0
    $pcOtherLogCount = 0
    if (Test-Path -LiteralPath $logsFolder) {
        $allLogs = @(Get-ChildItem -LiteralPath $logsFolder -Filter '*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
        $appLogs = @($allLogs | Where-Object { $_.Name -like 'lucas_pc_*.log' } | Select-Object -First 2)
        $otherLogs = @($allLogs | Where-Object { $_.Name -notlike 'lucas_pc_*.log' -and $_.Name -notlike 'bitmono-*.log' } | Select-Object -First 2)
        foreach ($lf in ($appLogs + $otherLogs)) {
            Copy-Item -LiteralPath $lf.FullName -Destination (Join-Path $pcDest $lf.Name) -Force -ErrorAction SilentlyContinue
        }
        $pcAppLogCount = $appLogs.Count
        $pcOtherLogCount = $otherLogs.Count
        [void]$sumSb.AppendLine("Da thu thap $pcAppLogCount file log phien PC (lucas_pc_*.log) + $pcOtherLogCount file .log khac trong Logs\")
    } else {
        [void]$sumSb.AppendLine("Thu muc Logs\ chua ton tai.")
    }
    if ($pcAppLogCount -eq 0) {
        $pcWarnings.Add('Chua co file log phien PC (Logs\lucas_pc_*.log)')
        [void]$sumSb.AppendLine("[CANH BAO] Chua co file lucas_pc_*.log nao trong Logs\.")
    }

    # 3. Sanitized app_settings.json (an sensitive values neu co)
    $appSet = Join-Path $srcRoot 'app_settings.json'
    if (Test-Path -LiteralPath $appSet) {
        try {
            $rawSet = [System.IO.File]::ReadAllText($appSet, [System.Text.Encoding]::UTF8)
            $sanitizedSet = [regex]::Replace($rawSet, '(?i)("(?:token|password|secret|api_key|key)"\s*:\s*")([^"]*)(")', '$1***REDACTED***$3')
            [System.IO.File]::WriteAllText((Join-Path $pcDest 'app_settings_sanitized.json'), $sanitizedSet, $utf8NoBom)
        } catch {}
    }

    # 4. Windows Application/.NET Runtime errors (last 24h)
    $winErrCount = 0
    try {
        $evSince = (Get-Date).AddHours(-24)
        $evs = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; Level = 1,2; StartTime = $evSince } -MaxEvents 20 -ErrorAction SilentlyContinue | Where-Object { $_.ProviderName -match 'Runtime|Application Error|LUCAS' -or $_.Message -match 'LUCAS|Lucas' })
        $winErrCount = $evs.Count
        if ($evs.Count -gt 0) {
            $evSb = New-Object System.Text.StringBuilder
            foreach ($ev in $evs) {
                [void]$evSb.AppendLine("[$($ev.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'))] [$($ev.ProviderName)] ID=$($ev.Id)")
                [void]$evSb.AppendLine(($ev.Message -replace '\r?\n', ' '))
                [void]$evSb.AppendLine('---')
            }
            [System.IO.File]::WriteAllText((Join-Path $pcDest 'windows_dotnet_errors.txt'), $evSb.ToString(), $utf8NoBom)
            [void]$sumSb.AppendLine("Phat hien $($evs.Count) su kien loi Windows/.NET trong 24h qua.")
        } else {
            [void]$sumSb.AppendLine("Su kien loi Windows/.NET (24h): 0 su kien.")
        }
    } catch {
        [void]$sumSb.AppendLine("Su kien loi Windows/.NET (24h): Khong doc duoc EventLog ($($_.Exception.Message)).")
    }

    return [PSCustomObject]@{
        Text          = $sumSb.ToString().TrimEnd()
        PcAppLogCount = $pcAppLogCount
        HasCrashDump  = $hasCrashDump
        WinErrCount   = $winErrCount
        Warnings      = @($pcWarnings)
    }
}

function New-SafeZipFromDirectory {
    param([string]$SourceDir, [string]$ZipPath)
    if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue }
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    if ([System.Type]::GetType('System.IO.Compression.ZipFile, System.IO.Compression.FileSystem')) {
        [System.IO.Compression.ZipFile]::CreateFromDirectory($SourceDir, $ZipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    } else {
        Compress-Archive -Path (Join-Path $SourceDir '*') -DestinationPath $ZipPath -Force
    }
}

function Write-BatchZipStage {
    param(
        [string]$StageDir,
        [string]$MasterPath,
        [string]$PcLogsDir,
        [string]$PcSummaryText,
        $BatchDevices,
        [bool]$IncludePcLogs,
        [string]$AdminPartFileName = '00_TOM_TAT_GUI_ADMIN_PART.txt'
    )
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    if (Test-Path -LiteralPath $StageDir) { Remove-Item -LiteralPath $StageDir -Recurse -Force -ErrorAction SilentlyContinue }
    [void](New-Item -ItemType Directory -Path $StageDir -Force)

    if ($MasterPath -and (Test-Path -LiteralPath $MasterPath)) {
        Copy-Item -LiteralPath $MasterPath -Destination (Join-Path $StageDir '00_TONG_HOP_LOI.txt') -Force -ErrorAction SilentlyContinue
    }
    if ($IncludePcLogs -and $PcLogsDir -and (Test-Path -LiteralPath $PcLogsDir)) {
        $pcDest = Join-Path $StageDir 'PC_Logs'
        [void](New-Item -ItemType Directory -Path $pcDest -Force)
        Copy-Item -Path (Join-Path $PcLogsDir '*') -Destination $pcDest -Recurse -Force -ErrorAction SilentlyContinue
    }

    $partSb = New-Object System.Text.StringBuilder
    if ($MasterPath -and (Test-Path -LiteralPath $MasterPath)) {
        [void]$partSb.AppendLine(([System.IO.File]::ReadAllText($MasterPath, [System.Text.Encoding]::UTF8)).TrimEnd())
    }
    if ($IncludePcLogs -and -not [string]::IsNullOrWhiteSpace($PcSummaryText)) {
        [void]$partSb.AppendLine('')
        [void]$partSb.AppendLine($PcSummaryText)
    }

    foreach ($r in $BatchDevices) {
        if ($r.SummaryFile -and (Test-Path -LiteralPath $r.SummaryFile)) {
            $sumLines = @(Get-Content -LiteralPath $r.SummaryFile -Encoding UTF8 -ErrorAction SilentlyContinue)
            [void]$partSb.AppendLine('')
            [void]$partSb.AppendLine("=== CHI TIET DAY DU MAY #$($r.Index): $($r.Model) [$($r.Serial)] ===")
            foreach ($sl in $sumLines) {
                [void]$partSb.AppendLine($sl)
            }
        }
        if (-not $r.DeviceDir -or -not (Test-Path -LiteralPath $r.DeviceDir)) { continue }
        $subName = Split-Path -Path $r.DeviceDir -Leaf
        $subDest = Join-Path $StageDir $subName
        [void](New-Item -ItemType Directory -Path $subDest -Force)
        foreach ($fn in @('01_TOM_TAT_LOI.txt', '02_logcat_full.txt', '03_logcat_crash.txt', '04_dmesg_kernel.txt', '05_thong_tin_he_thong_root.txt', '06_dropbox_crashes.txt')) {
            $srcF = Join-Path $r.DeviceDir $fn
            if (Test-Path -LiteralPath $srcF) {
                Copy-Item -LiteralPath $srcF -Destination (Join-Path $subDest $fn) -Force -ErrorAction SilentlyContinue
            }
        }
    }

    $partSummaryText = $partSb.ToString().TrimEnd()
    [System.IO.File]::WriteAllText((Join-Path $StageDir $AdminPartFileName), $partSummaryText, $utf8NoBom)
    return $partSummaryText
}

function Export-SessionZipPackages {
    param(
        [string]$SessionDir,
        [string]$MasterPath,
        [string]$AdminDigestPath,
        $Results,
        [string]$PcSummaryText,
        [string]$ExactSessionDir = '',
        [int]$MaxDevicesPerPart = 5,
        [long]$TargetMaxPartBytes = 1433600
    )
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $fullZipPath = Join-Path $SessionDir 'LUCAS_FULL_BUG_LOG.zip'
    $zipPath = Join-Path $SessionDir 'LUCAS_LOG_COMPACT.zip'
    $manifestPath = Join-Path $SessionDir '_parts_manifest.txt'
    $stageDir = Join-Path $SessionDir '_zip_stage'
    $probeZip = Join-Path $SessionDir '_probe_part.zip'
    $pcLogsDir = Join-Path $SessionDir 'PC_Logs'
    $resArr = @($Results | Sort-Object -Property Index)

    try {
        if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $fullZipPath) { Remove-Item -LiteralPath $fullZipPath -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $manifestPath) { Remove-Item -LiteralPath $manifestPath -Force -ErrorAction SilentlyContinue }

        # 1. Dong goi 1 ban FULL duy nhat (chi nhan ban LUCAS_LOG_COMPACT.zip khi chay CLI tay ngoai tool)
        if (Test-Path -LiteralPath $stageDir) { Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue }
        [void](New-Item -ItemType Directory -Path $stageDir -Force)
        Copy-Item -LiteralPath $MasterPath -Destination (Join-Path $stageDir '00_TONG_HOP_LOI.txt') -Force -ErrorAction SilentlyContinue
        Copy-Item -LiteralPath $AdminDigestPath -Destination (Join-Path $stageDir '00_TOM_TAT_GUI_ADMIN.txt') -Force -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $pcLogsDir) {
            $pcDest = Join-Path $stageDir 'PC_Logs'
            [void](New-Item -ItemType Directory -Path $pcDest -Force)
            Copy-Item -Path (Join-Path $pcLogsDir '*') -Destination $pcDest -Recurse -Force -ErrorAction SilentlyContinue
        }
        foreach ($r in $resArr) {
            if (-not $r.DeviceDir -or -not (Test-Path -LiteralPath $r.DeviceDir)) { continue }
            $subName = Split-Path -Path $r.DeviceDir -Leaf
            $subDest = Join-Path $stageDir $subName
            [void](New-Item -ItemType Directory -Path $subDest -Force)
            foreach ($fn in @('01_TOM_TAT_LOI.txt', '02_logcat_full.txt', '03_logcat_crash.txt', '04_dmesg_kernel.txt', '05_thong_tin_he_thong_root.txt', '06_dropbox_crashes.txt')) {
                $srcF = Join-Path $r.DeviceDir $fn
                if (Test-Path -LiteralPath $srcF) {
                    Copy-Item -LiteralPath $srcF -Destination (Join-Path $subDest $fn) -Force -ErrorAction SilentlyContinue
                }
            }
        }
        New-SafeZipFromDirectory -SourceDir $stageDir -ZipPath $fullZipPath
        if ([string]::IsNullOrWhiteSpace($ExactSessionDir) -and (Test-Path -LiteralPath $fullZipPath)) {
            Copy-Item -LiteralPath $fullZipPath -Destination $zipPath -Force -ErrorAction SilentlyContinue
        } else {
            $zipPath = $fullZipPath
        }

        $fullSize = if (Test-Path -LiteralPath $fullZipPath) { (Get-Item -LiteralPath $fullZipPath).Length } else { 0 }

        # 2. Neu it may (<=5) va <= ~1.37 MB -> giu nguyen 1 goi don, khong chia
        if ($resArr.Count -le 1 -or ($resArr.Count -le $MaxDevicesPerPart -and $fullSize -le $TargetMaxPartBytes)) {
            if ($fullSize -gt 0) {
                $lbl = if ($resArr.Count -eq 1) { "May #$($resArr[0].Index) $($resArr[0].Model) [$($resArr[0].Serial)]" } else { "$($resArr.Count) may (tron bo)" }
                [System.IO.File]::WriteAllText($manifestPath, "LUCAS_FULL_BUG_LOG.zip|1|1|$($resArr.Count)|$fullSize|$lbl|00_TOM_TAT_GUI_ADMIN.txt`n", $utf8NoBom)
            }
            return [PSCustomObject]@{ FullZip = $fullZipPath; CompactZip = $zipPath; ManifestPath = $manifestPath; PartCount = 1 }
        }

        # 3. Farm dong hoac goi > 1.37 MB -> tu dong chia nho thanh nhieu goi ZIP con, giu FULL 100% dong log
        $batches = New-Object System.Collections.Generic.List[object]
        $curBatch = New-Object System.Collections.Generic.List[object]
        for ($idx = 0; $idx -lt $resArr.Count; $idx++) {
            $dev = $resArr[$idx]
            if ($curBatch.Count -eq 0) {
                $curBatch.Add($dev)
                continue
            }
            if ($curBatch.Count -ge $MaxDevicesPerPart) {
                $batches.Add(@($curBatch.ToArray()))
                $curBatch = New-Object System.Collections.Generic.List[object]
                $curBatch.Add($dev)
                continue
            }
            $probeArr = @($curBatch.ToArray()) + @($dev)
            $includePc = ($batches.Count -eq 0)
            [void](Write-BatchZipStage -StageDir $stageDir -MasterPath $MasterPath -PcLogsDir $pcLogsDir -PcSummaryText $PcSummaryText -BatchDevices $probeArr -IncludePcLogs $includePc)
            New-SafeZipFromDirectory -SourceDir $stageDir -ZipPath $probeZip
            $probeLen = if (Test-Path -LiteralPath $probeZip) { (Get-Item -LiteralPath $probeZip).Length } else { 0 }
            if ($probeLen -le $TargetMaxPartBytes) {
                $curBatch.Add($dev)
            } else {
                $batches.Add(@($curBatch.ToArray()))
                $curBatch = New-Object System.Collections.Generic.List[object]
                $curBatch.Add($dev)
            }
        }
        if ($curBatch.Count -gt 0) {
            $batches.Add(@($curBatch.ToArray()))
        }

        if ($batches.Count -le 1) {
            if ($fullSize -gt 0) {
                $lblSingle = "$($resArr.Count) may (tron bo)"
                [System.IO.File]::WriteAllText($manifestPath, "LUCAS_FULL_BUG_LOG.zip|1|1|$($resArr.Count)|$fullSize|$lblSingle|00_TOM_TAT_GUI_ADMIN.txt`n", $utf8NoBom)
            }
            return [PSCustomObject]@{ FullZip = $fullZipPath; CompactZip = $zipPath; ManifestPath = $manifestPath; PartCount = 1 }
        }

        $totalParts = $batches.Count
        $mfLines = New-Object System.Collections.Generic.List[string]
        for ($p = 0; $p -lt $totalParts; $p++) {
            $partNum = $p + 1
            $partDevs = @($batches[$p])
            $partFile = ('LUCAS_PART_{0:D2}of{1:D2}.zip' -f $partNum, $totalParts)
            $partPath = Join-Path $SessionDir $partFile
            $partDigestName = ('_part_{0:D2}_digest.txt' -f $partNum)

            $partSummary = Write-BatchZipStage -StageDir $stageDir -MasterPath $MasterPath -PcLogsDir $pcLogsDir -PcSummaryText $PcSummaryText -BatchDevices $partDevs -IncludePcLogs ($p -eq 0)
            [System.IO.File]::WriteAllText((Join-Path $SessionDir $partDigestName), $partSummary, $utf8NoBom)
            New-SafeZipFromDirectory -SourceDir $stageDir -ZipPath $partPath

            $partBytes = if (Test-Path -LiteralPath $partPath) { (Get-Item -LiteralPath $partPath).Length } else { 0 }
            $firstDev = $partDevs[0]
            $lastDev = $partDevs[$partDevs.Count - 1]
            $devRange = if ($partDevs.Count -eq 1) {
                "May #$($firstDev.Index) $($firstDev.Model) [$($firstDev.Serial)]"
            } else {
                "May #$($firstDev.Index)..#$($lastDev.Index) ($($partDevs.Count) may)"
            }
            $mfLines.Add("$partFile|$partNum|$totalParts|$($partDevs.Count)|$partBytes|$devRange|$partDigestName")
        }
        [System.IO.File]::WriteAllText($manifestPath, (($mfLines.ToArray()) -join "`n") + "`n", $utf8NoBom)

        return [PSCustomObject]@{
            FullZip      = $fullZipPath
            CompactZip   = $zipPath
            ManifestPath = $manifestPath
            PartCount    = $totalParts
        }
    } catch {
        Write-Host "  [CANH BAO] Khong tao duoc file zip log: $($_.Exception.Message)" -ForegroundColor Yellow
        return [PSCustomObject]@{ FullZip = ''; CompactZip = ''; ManifestPath = ''; PartCount = 0 }
    } finally {
        Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $probeZip -Force -ErrorAction SilentlyContinue
    }
}

function Run-ParallelDump {
    param(
        [string]$AdbPath,
        $Targets,
        [string]$OutBaseDir,
        [bool]$NoPrompt = $false,
        [string]$ExactSessionDir = '',
        [bool]$CreateCompactZip = $false
    )

    $Targets = @($Targets)
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $sessionDir = if (-not [string]::IsNullOrWhiteSpace($ExactSessionDir)) {
        $ExactSessionDir
    } else {
        Join-Path $OutBaseDir "Logs_ThietBi\LOG_$ts"
    }
    [void](New-Item -ItemType Directory -Path $sessionDir -Force)

    Write-Host ''
    Write-Host ("Dang doc va phan tich log SONG SONG cho {0} thiet bi..." -f $Targets.Count) -ForegroundColor Cyan
    Write-Host ("Thu muc luu: $sessionDir") -ForegroundColor DarkGray
    Write-Host ''

    $maxThreads = [Math]::Min([Math]::Max($Targets.Count, 1), 16)
    $pool = [runspacefactory]::CreateRunspacePool(1, $maxThreads)
    $pool.Open()

    $workerText = $DeviceDumpWorker.ToString()
    $jobs = @()
    $idx = 0
    foreach ($dev in $Targets) {
        $idx++
        $ps = [powershell]::Create()
        $ps.RunspacePool = $pool
        [void]$ps.AddScript($workerText).AddArgument($AdbPath).AddArgument($dev).AddArgument($idx).AddArgument($sessionDir)
        $handle = $ps.BeginInvoke()
        $jobs += [PSCustomObject]@{
            PowerShell = $ps
            Handle     = $handle
            Device     = $dev
            Index      = $idx
            Done       = $false
        }
    }

    $results = @()
    $failedDevices = New-Object System.Collections.Generic.List[string]
    while (@($jobs | Where-Object { -not $_.Done }).Count -gt 0) {
        foreach ($j in $jobs) {
            if (-not $j.Done -and $j.Handle.IsCompleted) {
                $j.Done = $true
                try {
                    $res = $j.PowerShell.EndInvoke($j.Handle)
                    if ($j.PowerShell.HadErrors) {
                        $errMsg = ($j.PowerShell.Streams.Error | ForEach-Object { $_.ToString() }) -join '; '
                        Write-Host ("  [CANH BAO #{0}] {1}: {2}" -f $j.Index, $j.Device.Serial, $errMsg) -ForegroundColor Yellow
                    }
                    if ($res -and @($res).Count -gt 0) {
                        $r = @($res)[-1]
                        $results += $r
                        $errTotal = $r.FatalCount + $r.NativeCount + $r.AnrCount
                        $color = if ($errTotal -gt 0 -or $r.CompletenessTag -eq 'SOT_LOG!') { 'Red' } elseif ($r.GmsErrCount -gt 0 -or $r.HookErrCount -gt 0) { 'Yellow' } else { 'Green' }
                        Write-Host ("  [OK #{0}] {1} ({2}) | {3} dong [{4}] | {5} | Fatal:{6} Native:{7} ANR:{8} GMS:{9} | {10}s" -f $r.Index, $r.Model, $r.Serial, $r.TotalLogLines, $r.CompletenessTag, $r.LogcatRange, $r.FatalCount, $r.NativeCount, $r.AnrCount, $r.GmsErrCount, $r.DurationSec) -ForegroundColor $color
                    } else {
                        $failedDevices.Add("May #$($j.Index) [$($j.Device.Serial)]: Khong nhan duoc ket qua worker")
                        Write-Host ("  [LOI #{0}] {1}: Khong nhan duoc ket qua." -f $j.Index, $j.Device.Serial) -ForegroundColor Red
                    }
                } catch {
                    $failedDevices.Add("May #$($j.Index) [$($j.Device.Serial)]: $($_.Exception.Message)")
                    Write-Host ("  [LOI #{0}] {1}: {2}" -f $j.Index, $j.Device.Serial, $_.Exception.Message) -ForegroundColor Red
                } finally {
                    $j.PowerShell.Dispose()
                }
            }
        }
        Start-Sleep -Milliseconds 150
    }
    $pool.Close()
    $pool.Dispose()

    # Thu thap log phia PC Tool truoc de dua vao bao cao kiem tra do day du
    $pcInfo = Export-PcRuntimeLogs -PcDir $PcLogDir -FallbackRoot $OutBaseDir -SessionDir $sessionDir
    $pcSummaryText = $pcInfo.Text

    # Kiem tra tong the do day du log (Chong bo sot)
    $globalWarnings = New-Object System.Collections.Generic.List[string]
    foreach ($fd in $failedDevices) {
        $globalWarnings.Add($fd)
    }
    foreach ($pw in $pcInfo.Warnings) {
        $globalWarnings.Add("PC Tool: $pw")
    }
    foreach ($r in $results) {
        foreach ($mw in $r.MissingWarnings) {
            $globalWarnings.Add("May #$($r.Index) $($r.Model) [$($r.Serial)]: $mw")
        }
    }
    $globalStatus = if ($globalWarnings.Count -eq 0 -and $results.Count -eq $Targets.Count) {
        'PASS - THU THAP DU 100% NGUON LOG'
    } else {
        "CANH BAO SOT LOG ($($globalWarnings.Count) van de)"
    }

    # Tao file 00_TONG_HOP_LOI.txt tong ket tat ca cac may
    $results = @($results | Sort-Object -Property Index)
    $masterPath = Join-Path $sessionDir '00_TONG_HOP_LOI.txt'
    $mSb = New-Object System.Text.StringBuilder
    [void]$mSb.AppendLine('===============================================================================')
    [void]$mSb.AppendLine('   LUCAS SYSTEM - TONG HOP DOC LOG & CHAN DOAN LOI NHIEU THIET BI SONG SONG')
    [void]$mSb.AppendLine("   Thoi gian: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | So may da doc: $($results.Count)/$($Targets.Count)")
    [void]$mSb.AppendLine('===============================================================================')
    [void]$mSb.AppendLine('')
    [void]$mSb.AppendLine('--- [KIEM TRA DO DAY DU LOG - CHONG BO SOT] ---')
    [void]$mSb.AppendLine("  * Ket luan do du     : $globalStatus")
    [void]$mSb.AppendLine("  * Log phien PC (.log) : $($pcInfo.PcAppLogCount) file lucas_pc_*.log | crash_dump=$($pcInfo.HasCrashDump) | WinErr24h=$($pcInfo.WinErrCount)")
    if ($globalWarnings.Count -gt 0) {
        foreach ($gw in $globalWarnings) {
            [void]$mSb.AppendLine("  ! [SOT] $gw")
        }
    } else {
        [void]$mSb.AppendLine('  * Khong co may timeout, khong mat root, khong rong buffer.')
    }
    [void]$mSb.AppendLine('')
    [void]$mSb.AppendLine('STT | Serial               | Model          | Root          | Fatal | Native | ANR | GMS | Hook | SELinux | DongLog | KhungGioLog         | DoDuLog')
    [void]$mSb.AppendLine('----+----------------------+----------------+---------------+-------+--------+-----+-----+------+---------+---------+---------------------+--------------')
    foreach ($r in $results) {
        $rngDisplay = if ($r.LogcatRange.Length -gt 19) { $r.LogcatRange.Substring(0, 19) } else { $r.LogcatRange }
        [void]$mSb.AppendLine(('{0,-3} | {1,-20} | {2,-14} | {3,-13} | {4,5} | {5,6} | {6,3} | {7,3} | {8,4} | {9,7} | {10,7} | {11,-19} | {12}' -f `
            $r.Index, $r.Serial, $r.Model, $r.RootStatus, $r.FatalCount, $r.NativeCount, $r.AnrCount, $r.GmsErrCount, $r.HookErrCount, $r.SelinuxCount, $r.TotalLogLines, $rngDisplay, $r.CompletenessTag))
    }
    [void]$mSb.AppendLine('')
    [void]$mSb.AppendLine('===============================================================================')
    [void]$mSb.AppendLine('TRICH DOAN CRASH MOI NHAT TREN TUNG MAY (NEU CO)')
    [void]$mSb.AppendLine('===============================================================================')
    foreach ($r in $results) {
        [void]$mSb.AppendLine('')
        [void]$mSb.AppendLine(">>> May #$($r.Index): $($r.Model) [$($r.Serial)] | Trang thai: $($r.CompletenessTag) | Range: $($r.LogcatRange) | Thu muc: $($r.DeviceDir)")
        if ($r.FatalPreview) {
            [void]$mSb.AppendLine($r.FatalPreview)
        } else {
            [void]$mSb.AppendLine('(Khong phat hien Fatal/Native Crash moi trong buffer logcat)')
        }
        [void]$mSb.AppendLine('-------------------------------------------------------------------------------')
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($masterPath, $mSb.ToString(), $utf8NoBom)

    # Tao ban tom tat day du (00_TOM_TAT_GUI_ADMIN.txt) gom toan bo muc kiem tra + phan tich cua tung thiet bi + log PC
    $adminDigestPath = Join-Path $sessionDir '00_TOM_TAT_GUI_ADMIN.txt'
    $aSb = New-Object System.Text.StringBuilder
    [void]$aSb.AppendLine($mSb.ToString().TrimEnd())
    if ($pcSummaryText) {
        [void]$aSb.AppendLine('')
        [void]$aSb.AppendLine($pcSummaryText)
    }
    foreach ($r in $results) {
        if ($r.SummaryFile -and (Test-Path -LiteralPath $r.SummaryFile)) {
            $sumLines = @(Get-Content -LiteralPath $r.SummaryFile -Encoding UTF8 -ErrorAction SilentlyContinue)
            [void]$aSb.AppendLine('')
            [void]$aSb.AppendLine("=== CHI TIET DAY DU MAY #$($r.Index): $($r.Model) [$($r.Serial)] ===")
            foreach ($sl in $sumLines) {
                [void]$aSb.AppendLine($sl)
            }
        }
    }
    [System.IO.File]::WriteAllText($adminDigestPath, $aSb.ToString(), $utf8NoBom)

    $zipPath = ''
    $fullZipPath = ''
    $partCountCreated = 0
    if ($CreateCompactZip) {
        $pkgRes = Export-SessionZipPackages -SessionDir $sessionDir -MasterPath $masterPath -AdminDigestPath $adminDigestPath -Results $results -PcSummaryText $pcSummaryText -ExactSessionDir $ExactSessionDir
        $fullZipPath = $pkgRes.FullZip
        $zipPath = $pkgRes.CompactZip
        $partCountCreated = $pkgRes.PartCount
    }

    Write-Host ''
    Write-Host '===============================================================================' -ForegroundColor Green
    Write-Host " [HOAN TAT] Da xuat log xong $($results.Count) may!" -ForegroundColor Green
    Write-Host " File tong hop : $masterPath" -ForegroundColor White
    if ($zipPath -and (Test-Path -LiteralPath $zipPath)) {
        if ($partCountCreated -gt 1) {
            Write-Host " Chia nho farm : $partCountCreated goi ZIP (LUCAS_PART_*.zip) + Ban tong: $fullZipPath" -ForegroundColor White
        } else {
            Write-Host " File zip gon  : $zipPath" -ForegroundColor White
        }
    }
    Write-Host " Thu muc log   : $sessionDir" -ForegroundColor White
    Write-Host '===============================================================================' -ForegroundColor Green
    Write-Host ''
    if ($NoPrompt) { return }
    Write-Host 'Nhan [O] mo file tong hop | [F] mo thu muc log | [Enter] quay lai menu: ' -NoNewline -ForegroundColor Yellow
    $act = (Read-Host).Trim().ToUpper()
    if ($act -eq 'O') { Start-Process notepad.exe -ArgumentList "`"$masterPath`"" }
    elseif ($act -eq 'F') { Start-Process explorer.exe -ArgumentList "`"$sessionDir`"" }
}

function Run-LiveMonitor {
    param([string]$AdbPath, $Targets, [string]$OutBaseDir)

    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $liveDir = Join-Path $OutBaseDir "Logs_ThietBi\LIVE_$ts"
    [void](New-Item -ItemType Directory -Path $liveDir -Force)
    $allLiveFile = Join-Path $liveDir '00_LIVE_ALL.txt'

    Write-Host ''
    Write-Host "Dang bat dau THEO DOI LOI REAL-TIME cho $($Targets.Count) may..." -ForegroundColor Cyan
    Write-Host "Luu dong thoi vao: $liveDir" -ForegroundColor DarkGray
    Write-Host "Nhan phim [Q] de dung theo doi va luu file." -ForegroundColor Yellow
    Write-Host '-------------------------------------------------------------------------------'

    $queue = New-Object System.Collections.Concurrent.ConcurrentQueue[string]
    $procs = @()
    $handlers = @()

    foreach ($d in $Targets) {
        $serial = $d.Serial
        $tagName = if ($d.Model) { "$serial|$($d.Model)" } else { $serial }
        $safeSerial = ($serial -replace '[^a-zA-Z0-9._-]', '_')
        $devFile = Join-Path $liveDir "live_${safeSerial}.txt"

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $AdbPath
        $psi.Arguments = "-s `"$serial`" logcat -b main,system,crash -T 1 -v threadtime *:W"
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8

        $p = New-Object System.Diagnostics.Process
        $p.StartInfo = $psi
        $p.EnableRaisingEvents = $true

        $stateObj = [PSCustomObject]@{
            Tag     = $tagName
            Queue   = $queue
            DevFile = $devFile
        }
        $sub = Register-ObjectEvent -InputObject $p -EventName OutputDataReceived -MessageData $stateObj -Action {
            $line = $EventArgs.Data
            if ($null -ne $line -and $line -ne '') {
                $msgData = $Event.MessageData
                $formatted = "[$($msgData.Tag)] $line"
                $msgData.Queue.Enqueue($formatted)
            }
        }
        [void]$p.Start()
        $p.BeginOutputReadLine()
        $procs += [PSCustomObject]@{ Proc = $p; DevFile = $devFile; Tag = $tagName; Sub = $sub }
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $allSw = New-Object System.IO.StreamWriter($allLiveFile, $true, $utf8NoBom)
    $devWriters = @{}
    foreach ($pr in $procs) {
        $devWriters[$pr.Tag] = New-Object System.IO.StreamWriter($pr.DevFile, $true, $utf8NoBom)
    }

    $patternShow = 'FATAL|AndroidRuntime| E | F |ANR in|SIGSEGV|SIGABRT|PlayIntegrity|DroidGuard|DF-DFERH-01|LSPosed|Zygisk|resetprop|avc:\s*denied|OutOfMemoryError'
    try {
        while ($true) {
            $item = $null
            while ($queue.TryDequeue([ref]$item)) {
                $allSw.WriteLine($item)
                if ($item -match '^\[([^\]]+)\]\s*(.*)$') {
                    $t = $matches[1]
                    if ($devWriters.ContainsKey($t)) { $devWriters[$t].WriteLine($matches[2]) }
                }
                if ($item -match $patternShow) {
                    if ($item -match 'FATAL|AndroidRuntime|SIGSEGV|SIGABRT| F ') {
                        Write-Host $item -ForegroundColor Red
                    } elseif ($item -match 'ANR|avc:\s*denied|DF-DFERH-01|OutOfMemoryError') {
                        Write-Host $item -ForegroundColor Magenta
                    } else {
                        Write-Host $item -ForegroundColor Yellow
                    }
                }
            }
            $allSw.Flush()
            foreach ($w in $devWriters.Values) { $w.Flush() }

            if ([Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.Key -eq 'Q') { break }
            }
            Start-Sleep -Milliseconds 100
        }
    } finally {
        foreach ($pr in $procs) {
            try { Unregister-Event -SourceIdentifier $pr.Sub.Name -ErrorAction SilentlyContinue } catch {}
            try { if (-not $pr.Proc.HasExited) { $pr.Proc.Kill() } } catch {}
            try { $pr.Proc.Dispose() } catch {}
        }
        $allSw.Dispose()
        foreach ($w in $devWriters.Values) { $w.Dispose() }
    }

    Write-Host ''
    Write-Host "[DA DUNG] Log live da luu tai: $liveDir" -ForegroundColor Green
    Start-Sleep -Seconds 1
}

function Clear-DeviceLogcat {
    param([string]$AdbPath, $Targets)
    foreach ($d in $Targets) {
        $r = Invoke-AdbText -AdbPath $AdbPath -Arguments @('-s', $d.Serial, 'logcat', '-b', 'all', '-c') -TimeoutMs 8000
        if ($r.ExitCode -eq 0) {
            Write-Host "  [OK] Da xoa log cu tren $($d.Serial) ($($d.Model))" -ForegroundColor Green
        } else {
            Write-Host "  [LOI] Khong xoa duoc tren $($d.Serial): $($r.StdErr)" -ForegroundColor Red
        }
    }
    Write-Host 'San sang tai hien loi va doc log moi!' -ForegroundColor Cyan
    Start-Sleep -Seconds 2
}

# ======================= CHUONG TRINH CHINH =======================
$desktopDir = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktopDir) -or -not (Test-Path -LiteralPath $desktopDir)) {
    $desktopDir = $RootDir
}

$adbPath = Find-AdbExecutable -BaseDir $RootDir
if (-not $adbPath) {
    if ($IsAutoMode) {
        Write-Host '[LOI] Khong tim thay adb.exe trong che do auto!' -ForegroundColor Red
        exit 1
    }
    Write-Host '[CANH BAO] Khong tu tim thay adb.exe!' -ForegroundColor Red
    Write-Host 'Hay keo tha file adb.exe vao cua so nay roi nhan Enter:' -ForegroundColor Yellow
    $manual = (Read-Host).Trim().Trim('"')
    if ($manual -and (Test-Path -LiteralPath $manual)) {
        $adbPath = $manual
    } else {
        Write-Host '[LOI] Khong co adb.exe hop le.' -ForegroundColor Red
        exit 1
    }
}

if ($IsAutoMode) {
    $allDevs = @(Get-ConnectedDevices -AdbPath $adbPath)
    $online  = @($allDevs | Where-Object { $_.State -eq 'device' })
    if (-not [string]::IsNullOrWhiteSpace($FilterSerialsRaw)) {
        $wanted = @($FilterSerialsRaw.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
        if ($wanted.Count -gt 0) {
            $online = @($online | Where-Object { $wanted -contains $_.Serial })
        }
    }
    if ($online.Count -eq 0) {
        Write-Host '[CANH BAO] Khong tim thay thiet bi nao dang ket noi (trang thai device).' -ForegroundColor Yellow
        if (-not [string]::IsNullOrWhiteSpace($CustomOutDir)) {
            [void](New-Item -ItemType Directory -Path $CustomOutDir -Force)
            $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
            $noDevSb = New-Object System.Text.StringBuilder
            [void]$noDevSb.AppendLine("Khong phat hien thiet bi Android nao o trang thai ADB device tai thoi diem gui bao loi ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')).")
            $pcOnlyInfo = Export-PcRuntimeLogs -PcDir $PcLogDir -FallbackRoot $desktopDir -SessionDir $CustomOutDir
            [void]$noDevSb.AppendLine('')
            [void]$noDevSb.AppendLine('--- [KIEM TRA DO DAY DU LOG - CHONG BO SOT] ---')
            [void]$noDevSb.AppendLine("  * Thiet bi ADB        : 0 may online (chi doc duoc log PC Tool)")
            [void]$noDevSb.AppendLine("  * Log phien PC (.log) : $($pcOnlyInfo.PcAppLogCount) file lucas_pc_*.log | crash_dump=$($pcOnlyInfo.HasCrashDump) | WinErr24h=$($pcOnlyInfo.WinErrCount)")
            foreach ($pw in $pcOnlyInfo.Warnings) {
                [void]$noDevSb.AppendLine("  ! [SOT] PC Tool: $pw")
            }
            if ($pcOnlyInfo.Text) {
                [void]$noDevSb.AppendLine('')
                [void]$noDevSb.AppendLine($pcOnlyInfo.Text)
            }
            $noDevTxt = $noDevSb.ToString().TrimEnd()
            [System.IO.File]::WriteAllText((Join-Path $CustomOutDir '00_TONG_HOP_LOI.txt'), $noDevTxt, $utf8NoBom)
            [System.IO.File]::WriteAllText((Join-Path $CustomOutDir '00_TOM_TAT_GUI_ADMIN.txt'), $noDevTxt, $utf8NoBom)
            if ($CreateZipBundle) {
                $fullZipPath = Join-Path $CustomOutDir 'LUCAS_FULL_BUG_LOG.zip'
                $stageDir = Join-Path $CustomOutDir '_zip_stage'
                try {
                    if (Test-Path -LiteralPath $stageDir) { Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue }
                    [void](New-Item -ItemType Directory -Path $stageDir -Force)
                    Copy-Item -LiteralPath (Join-Path $CustomOutDir '00_TOM_TAT_GUI_ADMIN.txt') -Destination (Join-Path $stageDir '00_TOM_TAT_GUI_ADMIN.txt') -Force -ErrorAction SilentlyContinue
                    $pcLogsDir = Join-Path $CustomOutDir 'PC_Logs'
                    if (Test-Path -LiteralPath $pcLogsDir) {
                        $pcDest = Join-Path $stageDir 'PC_Logs'
                        [void](New-Item -ItemType Directory -Path $pcDest -Force)
                        Copy-Item -Path (Join-Path $pcLogsDir '*') -Destination $pcDest -Recurse -Force -ErrorAction SilentlyContinue
                    }
                    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
                    if ([System.Type]::GetType('System.IO.Compression.ZipFile, System.IO.Compression.FileSystem')) {
                        [System.IO.Compression.ZipFile]::CreateFromDirectory($stageDir, $fullZipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)
                    } else {
                        Compress-Archive -Path (Join-Path $stageDir '*') -DestinationPath $fullZipPath -Force
                    }
                } catch {} finally {
                    Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        }
        exit 2
    }
    Run-ParallelDump -AdbPath $adbPath -Targets $online -OutBaseDir $desktopDir -NoPrompt $true -ExactSessionDir $CustomOutDir -CreateCompactZip $CreateZipBundle
    exit 0
}

while ($true) {
    try { Clear-Host } catch {}
    Write-Host '===============================================================================' -ForegroundColor Cyan
    Write-Host '        LUCAS - CONG CU DOC & XUAT LOG NHIEU DIEN THOAI SONG SONG' -ForegroundColor Cyan
    Write-Host '===============================================================================' -ForegroundColor Cyan
    Write-Host (" ADB          : $adbPath") -ForegroundColor DarkGray
    Write-Host (" Noi luu log  : $desktopDir\Logs_ThietBi") -ForegroundColor DarkGray
    Write-Host ''

    $allDevs = @(Get-ConnectedDevices -AdbPath $adbPath)
    $online  = @($allDevs | Where-Object { $_.State -eq 'device' })
    $badDevs = @($allDevs | Where-Object { $_.State -ne 'device' })

    if ($allDevs.Count -eq 0) {
        Write-Host ' [!] Khong phat hien dien thoai nao dang cam qua USB / ADB.' -ForegroundColor Red
        Write-Host '     - Kiem tra cap USB / bat USB Debugging / cho phep ADB.' -ForegroundColor DarkGray
    } else {
        Write-Host (" Dang ket noi: {0} may san sang | {1} may loi ket noi" -f $online.Count, $badDevs.Count) -ForegroundColor White
        Write-Host '-------------------------------------------------------------------------------'
        $i = 0
        foreach ($d in $online) {
            $i++
            $m = if ($d.Model) { $d.Model } else { 'Unknown' }
            $c = if ($d.DeviceCode) { $d.DeviceCode } else { '-' }
            Write-Host ("  [{0}] {1,-22} | Model: {2,-15} | Code: {3}" -f $i, $d.Serial, $m, $c) -ForegroundColor Green
        }
        foreach ($b in $badDevs) {
            Write-Host ("  [X] {0,-22} | Trang thai: {1} (Hay kiem tra man hinh/cap)" -f $b.Serial, $b.State.ToUpper()) -ForegroundColor Red
        }
    }

    Write-Host '-------------------------------------------------------------------------------'
    Write-Host '  [1] Doc & xuat log TAT CA may dang cam (Chay song song)  [Mac dinh - Enter]' -ForegroundColor Yellow
    Write-Host '  [2] Chon rieng 1 hoac nhieu may de doc & xuat log'
    Write-Host '  [3] Theo doi loi Real-Time (Live Logcat Error Monitor)'
    Write-Host '  [4] Xoa log cu tren may (logcat -c) truoc khi test lai loi'
    Write-Host '  [0] Quet lai danh sach thiet bi'
    Write-Host '  [X] Thoat'
    Write-Host '-------------------------------------------------------------------------------'
    Write-Host 'Lua chon cua sep [1]: ' -NoNewline -ForegroundColor Cyan
    $choice = (Read-Host).Trim().ToUpper()
    if ($choice -eq '') { $choice = '1' }

    if ($choice -eq 'X') { break }
    if ($choice -eq '0') { continue }

    if ($online.Count -eq 0) {
        Write-Host ''
        Write-Host '[LOI] Chua co may nao o trang thai device!' -ForegroundColor Red
        Start-Sleep -Seconds 2
        continue
    }

    switch ($choice) {
        '1' { Run-ParallelDump -AdbPath $adbPath -Targets $online -OutBaseDir $desktopDir }
        '2' {
            $picked = @(Select-TargetDevices -OnlineDevices $online)
            if ($picked.Count -gt 0) {
                Run-ParallelDump -AdbPath $adbPath -Targets $picked -OutBaseDir $desktopDir
            } else {
                Write-Host 'Khong co may nao duoc chon.' -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
        '3' {
            $picked = @(Select-TargetDevices -OnlineDevices $online)
            if ($picked.Count -gt 0) {
                Run-LiveMonitor -AdbPath $adbPath -Targets $picked -OutBaseDir $desktopDir
            }
        }
        '4' {
            $picked = @(Select-TargetDevices -OnlineDevices $online)
            if ($picked.Count -gt 0) {
                Clear-DeviceLogcat -AdbPath $adbPath -Targets $picked
            }
        }
        Default {
            Write-Host 'Lua chon khong hop le!' -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
}
